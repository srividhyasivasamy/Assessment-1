<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Birbal received his entire education in I_4eaf56</name>
   <tag></tag>
   <elementGuidId>f5686111-3fa9-41b5-af31-0c2e23797e90</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.text-justify</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Birbal received his entire education in India at Lahore, first at the Mission an&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>a298a039-1a8f-4749-b252-562f03632bf2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-justify</value>
      <webElementGuid>141a42db-dc5d-4464-b0ef-b562823c36d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                     
                                        Birbal received his entire education in India at Lahore, first at the Mission and Central Model Schools and then at the Government College, where his father held one of the chairs in chemistry. He gained many academic distinctions, standing first in Sanskrit at the Matriculation examination of the Punjab University and attaining a province position in Intermediate Science.
                                        
                                        His partiality for Sanskrit endured till the very end, and indeed, in later years he became much devoted to it. He graduated in 1911 from Lahore, and in the same year joined Emmanuel College, Cambridge.
                                        
                                        Birbal graduated from Cambridge in 1911 and soon settled down to research. He commenced to take keen interest in research under the inspiring, leadership and guidance of one of the most distinguished botanists of the day, Prof. A. C. Seward was an inspiration to listen to his discourses on living and fossil plants, but a source of added pride when the name of Birbal, one of his favorite students, was mentioned in connection with the study of the Gondwana and other floras. Prof. and Mrs. Seward had a soft corner towards Birbal and always wrote to him in affectionate terms. It was a relationship deeper and more beautiful than between a teacher and his pupil and which Birbal cherished more than many other things. Birbal's interest and knowledge of Indian living plants was recognized early, for, yet a student at Cambridge, he was asked to revise Lowson's text-book of botany, now one of the widely used books on the subject in Indian schools and colleges.
                                        
                                        For his researches on fossil plants he was awarded the D.Sc. degree of London University in 1919. Returning home in the same year he not only continued his investigations, but collected around him a group of devoted students, from all parts of the country, raising high the status of Palaeobotany in India. Early during his career in India, Birbal was paid a great compliment by Prof. Seward when the latter declined to undertake the study of certain fossil collections from India saying that the first right lay with his young pupil. The material ultimately came to Birbal. This paved the way for his future field of research, and thus commenced a long and enduring association with the Geological Survey of India. Times have been numerous when Birbal has gratefully acknowledged this fine gesture on the part of his teacher whom he esteemed and loved beyond measure. And the Geological Survey of India has commemorated him by erecting a bust in his honour. In addition to the numerous palaeobotanical researches that he published, he made important contributions to the problems connected with the age of the Saline Series of the Punjab Salt Range and the age of the Deccan Traps.
                                        
                                        In 1921 he took charge of the newly opened Botany Department of Lucknow University, as its first Professor. He immediately threw himself heart and soul into the work of organizing. Despite his other preoccupations, he was often seen grinding and making thin sections of fossil plants with his own hands. By hard work and persuasive charm, he built up a reputation for the University which soon became the first centre of botanical and palaeobotanical investigations in India.
                                        
                                        The University of Cambridge recognized his researches by the award of the degree of Sc.D. in 1929, the first perhaps to be awarded to an Indian scientist. The highest British scientific honour came to him in 1936, when he was elected a Fellow of the Royal Society of London. He was elected Vice-President, Palaeobotany Section, 5th and 6th International Botanical Congresses, 1930 and 1935, respectively; General President of the Indian Science Congress for 1940; President, National Academy of Sciences, India, 1937-39 and 1943-44. In 1948 he was elected a Foreign Honorary Member of the American Academy of Arts and Sciences. Another high honour which came to him was his election as an Honorary President of the International Botanical Congress, Stockholm, 1950.
                                    </value>
      <webElementGuid>5de2a688-0f55-41bb-9de0-8845e61b6758</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-10 col-lg-10 col-md-8 col-sm-12 col-xs-12&quot;]/div[@class=&quot;col-md-12&quot;]/p[@class=&quot;text-justify&quot;]</value>
      <webElementGuid>b64b4e04-3436-4c7f-868d-063ae07f8b50</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div/p</value>
      <webElementGuid>02748f88-bcee-481c-86ff-e15f3769cf72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission at Cambridge University'])[1]/following::p[1]</value>
      <webElementGuid>3478d9a1-5b5a-4d2a-b1c8-a930f03438d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mrs. Savitri Sahni'])[2]/following::p[1]</value>
      <webElementGuid>a5fa4392-62ad-4829-a5ea-3b53e865f100</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Important Links'])[1]/preceding::p[2]</value>
      <webElementGuid>f2082529-0714-45cb-b5c5-94a2064b2894</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/preceding::p[2]</value>
      <webElementGuid>4a0aec1b-65c9-4ab7-8446-58a8e4885133</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Birbal received his entire education in India at Lahore, first at the Mission and Central Model Schools and then at the Government College, where his father held one of the chairs in chemistry. He gained many academic distinctions, standing first in Sanskrit at the Matriculation examination of the Punjab University and attaining a province position in Intermediate Science.']/parent::*</value>
      <webElementGuid>185921b4-199a-4d8a-b49b-4e0671ea6082</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/p</value>
      <webElementGuid>8e01e022-1bb9-4993-8220-4c611fe3cc06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = concat(&quot;
                                     
                                        Birbal received his entire education in India at Lahore, first at the Mission and Central Model Schools and then at the Government College, where his father held one of the chairs in chemistry. He gained many academic distinctions, standing first in Sanskrit at the Matriculation examination of the Punjab University and attaining a province position in Intermediate Science.
                                        
                                        His partiality for Sanskrit endured till the very end, and indeed, in later years he became much devoted to it. He graduated in 1911 from Lahore, and in the same year joined Emmanuel College, Cambridge.
                                        
                                        Birbal graduated from Cambridge in 1911 and soon settled down to research. He commenced to take keen interest in research under the inspiring, leadership and guidance of one of the most distinguished botanists of the day, Prof. A. C. Seward was an inspiration to listen to his discourses on living and fossil plants, but a source of added pride when the name of Birbal, one of his favorite students, was mentioned in connection with the study of the Gondwana and other floras. Prof. and Mrs. Seward had a soft corner towards Birbal and always wrote to him in affectionate terms. It was a relationship deeper and more beautiful than between a teacher and his pupil and which Birbal cherished more than many other things. Birbal&quot; , &quot;'&quot; , &quot;s interest and knowledge of Indian living plants was recognized early, for, yet a student at Cambridge, he was asked to revise Lowson&quot; , &quot;'&quot; , &quot;s text-book of botany, now one of the widely used books on the subject in Indian schools and colleges.
                                        
                                        For his researches on fossil plants he was awarded the D.Sc. degree of London University in 1919. Returning home in the same year he not only continued his investigations, but collected around him a group of devoted students, from all parts of the country, raising high the status of Palaeobotany in India. Early during his career in India, Birbal was paid a great compliment by Prof. Seward when the latter declined to undertake the study of certain fossil collections from India saying that the first right lay with his young pupil. The material ultimately came to Birbal. This paved the way for his future field of research, and thus commenced a long and enduring association with the Geological Survey of India. Times have been numerous when Birbal has gratefully acknowledged this fine gesture on the part of his teacher whom he esteemed and loved beyond measure. And the Geological Survey of India has commemorated him by erecting a bust in his honour. In addition to the numerous palaeobotanical researches that he published, he made important contributions to the problems connected with the age of the Saline Series of the Punjab Salt Range and the age of the Deccan Traps.
                                        
                                        In 1921 he took charge of the newly opened Botany Department of Lucknow University, as its first Professor. He immediately threw himself heart and soul into the work of organizing. Despite his other preoccupations, he was often seen grinding and making thin sections of fossil plants with his own hands. By hard work and persuasive charm, he built up a reputation for the University which soon became the first centre of botanical and palaeobotanical investigations in India.
                                        
                                        The University of Cambridge recognized his researches by the award of the degree of Sc.D. in 1929, the first perhaps to be awarded to an Indian scientist. The highest British scientific honour came to him in 1936, when he was elected a Fellow of the Royal Society of London. He was elected Vice-President, Palaeobotany Section, 5th and 6th International Botanical Congresses, 1930 and 1935, respectively; General President of the Indian Science Congress for 1940; President, National Academy of Sciences, India, 1937-39 and 1943-44. In 1948 he was elected a Foreign Honorary Member of the American Academy of Arts and Sciences. Another high honour which came to him was his election as an Honorary President of the International Botanical Congress, Stockholm, 1950.
                                    &quot;) or . = concat(&quot;
                                     
                                        Birbal received his entire education in India at Lahore, first at the Mission and Central Model Schools and then at the Government College, where his father held one of the chairs in chemistry. He gained many academic distinctions, standing first in Sanskrit at the Matriculation examination of the Punjab University and attaining a province position in Intermediate Science.
                                        
                                        His partiality for Sanskrit endured till the very end, and indeed, in later years he became much devoted to it. He graduated in 1911 from Lahore, and in the same year joined Emmanuel College, Cambridge.
                                        
                                        Birbal graduated from Cambridge in 1911 and soon settled down to research. He commenced to take keen interest in research under the inspiring, leadership and guidance of one of the most distinguished botanists of the day, Prof. A. C. Seward was an inspiration to listen to his discourses on living and fossil plants, but a source of added pride when the name of Birbal, one of his favorite students, was mentioned in connection with the study of the Gondwana and other floras. Prof. and Mrs. Seward had a soft corner towards Birbal and always wrote to him in affectionate terms. It was a relationship deeper and more beautiful than between a teacher and his pupil and which Birbal cherished more than many other things. Birbal&quot; , &quot;'&quot; , &quot;s interest and knowledge of Indian living plants was recognized early, for, yet a student at Cambridge, he was asked to revise Lowson&quot; , &quot;'&quot; , &quot;s text-book of botany, now one of the widely used books on the subject in Indian schools and colleges.
                                        
                                        For his researches on fossil plants he was awarded the D.Sc. degree of London University in 1919. Returning home in the same year he not only continued his investigations, but collected around him a group of devoted students, from all parts of the country, raising high the status of Palaeobotany in India. Early during his career in India, Birbal was paid a great compliment by Prof. Seward when the latter declined to undertake the study of certain fossil collections from India saying that the first right lay with his young pupil. The material ultimately came to Birbal. This paved the way for his future field of research, and thus commenced a long and enduring association with the Geological Survey of India. Times have been numerous when Birbal has gratefully acknowledged this fine gesture on the part of his teacher whom he esteemed and loved beyond measure. And the Geological Survey of India has commemorated him by erecting a bust in his honour. In addition to the numerous palaeobotanical researches that he published, he made important contributions to the problems connected with the age of the Saline Series of the Punjab Salt Range and the age of the Deccan Traps.
                                        
                                        In 1921 he took charge of the newly opened Botany Department of Lucknow University, as its first Professor. He immediately threw himself heart and soul into the work of organizing. Despite his other preoccupations, he was often seen grinding and making thin sections of fossil plants with his own hands. By hard work and persuasive charm, he built up a reputation for the University which soon became the first centre of botanical and palaeobotanical investigations in India.
                                        
                                        The University of Cambridge recognized his researches by the award of the degree of Sc.D. in 1929, the first perhaps to be awarded to an Indian scientist. The highest British scientific honour came to him in 1936, when he was elected a Fellow of the Royal Society of London. He was elected Vice-President, Palaeobotany Section, 5th and 6th International Botanical Congresses, 1930 and 1935, respectively; General President of the Indian Science Congress for 1940; President, National Academy of Sciences, India, 1937-39 and 1943-44. In 1948 he was elected a Foreign Honorary Member of the American Academy of Arts and Sciences. Another high honour which came to him was his election as an Honorary President of the International Botanical Congress, Stockholm, 1950.
                                    &quot;))]</value>
      <webElementGuid>257007bb-0549-4b9f-a9ea-0522f4f143db</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
