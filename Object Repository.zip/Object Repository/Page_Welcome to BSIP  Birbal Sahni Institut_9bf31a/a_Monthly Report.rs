<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Monthly Report</name>
   <tag></tag>
   <elementGuidId>d8f7a202-2092-454b-9532-27978e8535a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord']/ul/li[6]/ul/li[6]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(6) > ul.dropdown > li:nth-of-type(6) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Monthly Report&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3e3d6ba9-8831-4032-a4a7-a4e9f1744070</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>bsip_monthly_report.php</value>
      <webElementGuid>20f8e0b1-fd7e-4def-87b0-beca23ff47ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Monthly Report</value>
      <webElementGuid>9a9a969d-e03e-4851-82ff-5338d70fe0fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord&quot;)/ul[@class=&quot;menuzord-menu menuzord-indented scrollable&quot;]/li[6]/ul[@class=&quot;dropdown&quot;]/li[6]/a[1]</value>
      <webElementGuid>286e734f-2c94-4e49-bc3f-c3a67ed1a9d1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='menuzord']/ul/li[6]/ul/li[6]/a</value>
      <webElementGuid>b10c6bd8-25e7-4866-a4ff-0d9235c60fa0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Monthly Report')]</value>
      <webElementGuid>ec0c3fe5-fb8c-4ac7-b03a-d78e4c026c1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research Papers'])[1]/following::a[1]</value>
      <webElementGuid>576802dc-e73d-4703-9314-fc60f5ead804</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publications On Sale'])[1]/following::a[2]</value>
      <webElementGuid>03a404ef-1a70-4f31-bfac-d48f1ba11fbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Newsletter'])[1]/preceding::a[1]</value>
      <webElementGuid>561e633f-06b8-42c9-82a1-96a132b968e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Units'])[1]/preceding::a[2]</value>
      <webElementGuid>400e085b-b2fb-467d-bd9a-20caa80eb4a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Monthly Report']/parent::*</value>
      <webElementGuid>4bb42e9d-e3ec-4b84-9891-6778647e44b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'bsip_monthly_report.php')]</value>
      <webElementGuid>bbc53236-2876-4bdc-90f8-7de8cfc1d297</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/ul/li[6]/a</value>
      <webElementGuid>6b855ddf-2978-445a-a5ba-4fb21dd64112</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'bsip_monthly_report.php' and (text() = 'Monthly Report' or . = 'Monthly Report')]</value>
      <webElementGuid>68029eec-a01e-493b-b284-b0a776365cc2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
