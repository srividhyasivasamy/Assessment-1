<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Rajbhasha Patal</name>
   <tag></tag>
   <elementGuidId>8271efb8-c6ed-4e7a-9c58-cdf87cc02a7f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord']/ul/li[12]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(12) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Rajbhasha Patal&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9f64ec4b-904d-4234-95f4-3ca994342344</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>bsip_rajbhasha_patal.php</value>
      <webElementGuid>d5f06ed6-c40d-4572-9d4e-f9d87d248e92</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Rajbhasha Patal</value>
      <webElementGuid>f267aae0-f209-4262-83cf-8768dc38cb90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord&quot;)/ul[@class=&quot;menuzord-menu menuzord-indented scrollable&quot;]/li[12]/a[1]</value>
      <webElementGuid>4c8ba133-19ac-4546-8912-6d8b15c0af0a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='menuzord']/ul/li[12]/a</value>
      <webElementGuid>9bdc01fc-c559-4185-813b-76bfae7ccbab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Rajbhasha Patal')]</value>
      <webElementGuid>eecf51a9-07da-4cbf-8949-c66788e6e941</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Past Events'])[1]/following::a[1]</value>
      <webElementGuid>0bac09de-9975-43ed-af85-1d366c279753</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Picture Gallery'])[1]/following::a[2]</value>
      <webElementGuid>b59c6f52-6c99-4bc6-9d63-9808216a7eb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='❌'])[1]/preceding::a[1]</value>
      <webElementGuid>4f2b776c-c7ea-400b-a3c1-b0e015a5775b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A+'])[1]/preceding::a[1]</value>
      <webElementGuid>0f9e6c25-3526-4a0f-a094-f9ae8659cf04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Rajbhasha Patal']/parent::*</value>
      <webElementGuid>d1d9d66c-8a2c-4530-a40a-60f228e47733</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'bsip_rajbhasha_patal.php')]</value>
      <webElementGuid>e4b19ec2-5c75-4def-a91f-1c020b44cab9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[12]/a</value>
      <webElementGuid>32fd1245-6b0a-4f2c-936a-213f4ce7ebc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'bsip_rajbhasha_patal.php' and (text() = 'Rajbhasha Patal' or . = 'Rajbhasha Patal')]</value>
      <webElementGuid>1b314060-9f84-4444-a6ae-8b4d179fbbcc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
