<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Superannuated_fa fa-angle-down</name>
   <tag></tag>
   <elementGuidId>50f25a51-12c3-49e7-9f27-82a8da8482e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord']/ul/li[5]/a/span/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(5) > a > span.indicator > i.fa.fa-angle-down</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Research &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>75b0afac-eb6d-4774-838d-1811810cc12f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-angle-down</value>
      <webElementGuid>92bffb10-3172-4f4f-bfdb-c9816032f0a1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord&quot;)/ul[@class=&quot;menuzord-menu menuzord-indented scrollable&quot;]/li[5]/a[1]/span[@class=&quot;indicator&quot;]/i[@class=&quot;fa fa-angle-down&quot;]</value>
      <webElementGuid>095b7fc9-663f-4b4a-8cd5-f72ea6736281</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='menuzord']/ul/li[5]/a/span/i</value>
      <webElementGuid>d8672cde-9ab8-4a0c-98d4-a2806ab38e07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a/span/i</value>
      <webElementGuid>08675aa0-016e-4328-8a37-dfa47eb3fbf7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
