<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Read                                     _57666f</name>
   <tag></tag>
   <elementGuidId>82220525-831f-475d-9cdb-046fc0423bd5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='about ']/div/div/div/div/div/div[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-default.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Read More&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7506bbda-9041-4d93-934c-c82cd0b9f97a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>bsip_institute_history.php</value>
      <webElementGuid>3bc45fef-df07-4f3c-8a61-b9762aa71148</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default btn-sm</value>
      <webElementGuid>e6758ce1-b492-48f8-8349-be8a91a8ce99</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Read
                                            More</value>
      <webElementGuid>82d3b91e-7d9e-4b4f-aeba-08a38295dcba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;about &quot;)/div[@class=&quot;container-fluid pt-20 pb-20&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-6 col-md-4&quot;]/div[@class=&quot;team-members border-bottom-theme-colored2px text-center maxwidth400 mb-30&quot;]/div[@class=&quot;team-details&quot;]/a[@class=&quot;btn btn-default btn-sm&quot;]</value>
      <webElementGuid>2478d3c7-93a4-440c-ab5b-50a7838fad2b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='about ']/div/div/div/div/div/div[3]/a</value>
      <webElementGuid>60f5ea54-130c-43c6-bd66-47cf69ac9018</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Read
                                            More')]</value>
      <webElementGuid>2878313a-ed98-4a68-8a90-23158d1ebaec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::a[1]</value>
      <webElementGuid>f8aa9882-622e-4855-b309-ea00d5bdd8a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Prof. Birbal Sahni, FRS'])[1]/preceding::a[1]</value>
      <webElementGuid>c9007feb-a159-4a56-86eb-e113a4bcd7db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'bsip_institute_history.php')])[2]</value>
      <webElementGuid>3fbf0314-e9dc-439c-81a4-13e0ddcb532f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a</value>
      <webElementGuid>8aa227ec-3118-40ce-b73c-585902df1003</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'bsip_institute_history.php' and (text() = 'Read
                                            More' or . = 'Read
                                            More')]</value>
      <webElementGuid>d084c567-edbb-45fe-a970-56bf5686864b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
