<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_View Profile</name>
   <tag></tag>
   <elementGuidId>30408a18-2afa-481c-afb6-f4518850eed9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='about ']/div/div/div/div[2]/div/div[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;View Profile&quot;i] >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a851e1ad-9413-412f-b70d-41a7fbf5abb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>bsip_Prof_birbal_Sahni_background.php</value>
      <webElementGuid>7ae7ca7a-ee57-43b9-a401-f8e13183f3d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default btn-sm</value>
      <webElementGuid>75711946-13e2-4310-a133-23a160d8aba3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>View Profile</value>
      <webElementGuid>3d535655-8c3d-4180-8e3f-1958f1c7aeab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;about &quot;)/div[@class=&quot;container-fluid pt-20 pb-20&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-6 col-md-4&quot;]/div[@class=&quot;team-members border-bottom-theme-colored2px text-center maxwidth400 mb-30&quot;]/div[@class=&quot;team-details&quot;]/a[@class=&quot;btn btn-default btn-sm&quot;]</value>
      <webElementGuid>bee240c4-9c42-49b2-9f07-b67b2ca62022</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='about ']/div/div/div/div[2]/div/div[3]/a</value>
      <webElementGuid>8e0e8dff-ed48-43d3-a9af-9d2d01c60aa6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'View Profile')]</value>
      <webElementGuid>c0f42e05-37f6-46df-a1f1-3c7173317e8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Founder BSIP'])[1]/following::a[1]</value>
      <webElementGuid>9eea7e00-4443-4d5b-91d2-4ffd648fa72b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Prof. Birbal Sahni, FRS'])[1]/following::a[1]</value>
      <webElementGuid>d54d4f09-d690-4c10-b8fb-e7d098c2ddc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Prof. Mahesh G. Thakkar'])[1]/preceding::a[1]</value>
      <webElementGuid>2173a95f-b552-4fea-a996-a8a67b4eaef5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='View Profile']/parent::*</value>
      <webElementGuid>537e51eb-aae0-423c-a0d6-67aabd3a5d1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'bsip_Prof_birbal_Sahni_background.php')])[2]</value>
      <webElementGuid>f0767eae-48f8-449f-a7db-d3d322d0ed41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[3]/a</value>
      <webElementGuid>2d790485-60f4-454d-94b0-236f869849b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'bsip_Prof_birbal_Sahni_background.php' and (text() = 'View Profile' or . = 'View Profile')]</value>
      <webElementGuid>a1813a53-7203-4ddd-88e7-67fb6c607769</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
