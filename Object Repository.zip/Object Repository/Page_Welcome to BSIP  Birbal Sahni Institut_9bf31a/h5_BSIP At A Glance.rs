<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_BSIP At A Glance</name>
   <tag></tag>
   <elementGuidId>00a5e3bd-93f6-4fad-b38c-8988c19765a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='about ']/div/div/div/div/div/div/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h5.text-uppercase.text-white.mb-0.mt-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;BSIP At A Glance&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>57821979-66a9-4051-8968-1b0b39bcf15c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-uppercase text-white mb-0 mt-0</value>
      <webElementGuid>881b01dd-3ee6-4f11-81b0-b9c1649143b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                             BSIP At A Glance
                                        </value>
      <webElementGuid>7b113f2f-4a32-4830-8348-9a6a303d457b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;about &quot;)/div[@class=&quot;container-fluid pt-20 pb-20&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-6 col-md-4&quot;]/div[@class=&quot;team-members border-bottom-theme-colored2px text-center maxwidth400 mb-30&quot;]/div[@class=&quot;event-title&quot;]/h5[@class=&quot;text-uppercase text-white mb-0 mt-0&quot;]</value>
      <webElementGuid>4e231228-c2d1-4331-9be1-ce5abd777845</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='about ']/div/div/div/div/div/div/h5</value>
      <webElementGuid>93724ccd-0f59-4176-8472-108870245226</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::h5[1]</value>
      <webElementGuid>72d13169-a853-4d7e-8965-6b54c62fb615</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[1]/following::h5[1]</value>
      <webElementGuid>3fdf3b32-c77b-4297-8dd3-2253195d4802</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='BSIP At A Glance']/parent::*</value>
      <webElementGuid>e085ecba-8398-4da3-a94c-67340af14ac2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5</value>
      <webElementGuid>261264c5-d1b2-4b00-bac6-52e4bf31b860</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = '
                                             BSIP At A Glance
                                        ' or . = '
                                             BSIP At A Glance
                                        ')]</value>
      <webElementGuid>ecb6919f-dccf-4ead-8284-7655560f6a4c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
