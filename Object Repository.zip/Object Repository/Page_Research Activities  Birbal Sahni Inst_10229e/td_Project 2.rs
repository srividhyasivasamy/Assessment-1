<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Project 2</name>
   <tag></tag>
   <elementGuidId>6013f5ba-94a5-4e34-a3a7-a2197849d8fc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='9']/div/div/div[2]/div/table/tbody/tr/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Project 2&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>bfe5966a-da93-4d5b-b726-4dec74a66f0a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Project 2</value>
      <webElementGuid>c2a76be5-f85e-485d-9907-27e210a6f08d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;9&quot;)/div[@class=&quot;panel-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;sponsered-project-container&quot;]/table[@class=&quot;table mb-0&quot;]/tbody[1]/tr[1]/td[2]</value>
      <webElementGuid>c0e5f3e3-82d5-4731-ac08-8c9b00cfdd2d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='9']/div/div/div[2]/div/table/tbody/tr/td[2]</value>
      <webElementGuid>f79246f7-0f7e-4128-a647-faf77c4ac01b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Project No.'])[2]/following::td[1]</value>
      <webElementGuid>2e770a3b-0278-4553-b833-b0b5e8d65dd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Description'])[1]/following::td[3]</value>
      <webElementGuid>5ec8956c-8835-4a27-b9f3-60f0fb8e5b29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Project Title'])[2]/preceding::td[1]</value>
      <webElementGuid>73d7db8e-0c71-45f9-9414-4d846d44f362</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Biostratigraphy, Basin correlation, climatic and Biotic events During Palaeozoic &amp; Mesozoic'])[1]/preceding::td[2]</value>
      <webElementGuid>d0237dcc-6715-4b6d-8d9a-634e34e1dcf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Project 2']/parent::*</value>
      <webElementGuid>5d11bb2d-5f92-4db9-9f03-2a9bb25b5b4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/table/tbody/tr/td[2]</value>
      <webElementGuid>5953faf1-c040-47cc-9708-6241d3dae693</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Project 2' or . = 'Project 2')]</value>
      <webElementGuid>8d162f0d-1837-458b-8656-62fed83c7aed</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
