<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Quaternary Lake Drilling Project QLDP</name>
   <tag></tag>
   <elementGuidId>b38fd1c4-27d7-43df-aac2-a660a4bd5d8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='9']/div/div/div[8]/div/table/tbody/tr[7]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-success</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Quaternary Lake Drilling Project QLDP&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6b635fbe-73cf-4df6-882c-3238ec1c6078</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>bsip_qldp.php</value>
      <webElementGuid>12a9af9f-d555-471a-87ed-52acd9716251</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-success</value>
      <webElementGuid>bc265ce7-8333-4b1e-bf18-ac43f0236b7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Quaternary Lake Drilling Project QLDP</value>
      <webElementGuid>dec4032a-6171-46c6-96b6-d0f4b493afeb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;9&quot;)/div[@class=&quot;panel-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;sponsered-project-container&quot;]/table[@class=&quot;table mb-0&quot;]/tbody[1]/tr[7]/td[2]/a[@class=&quot;btn btn-success&quot;]</value>
      <webElementGuid>fe910080-901b-4cab-b4c5-16166b0bca5e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='9']/div/div/div[8]/div/table/tbody/tr[7]/td[2]/a</value>
      <webElementGuid>cfc8d692-133f-40c0-a24f-b688c8b29d5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Quaternary Lake Drilling Project QLDP')]</value>
      <webElementGuid>f1f11b83-dde1-4481-b5ed-da91b72ddb79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Description'])[8]/following::a[1]</value>
      <webElementGuid>e29fd2e1-73d7-4d72-bb25-6468c712ad4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Associate Members'])[8]/following::a[1]</value>
      <webElementGuid>57f23e3f-3195-4cb2-8bfb-310a9c44f48d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Project 9'])[1]/preceding::a[2]</value>
      <webElementGuid>2596040a-1e7b-4435-a391-0d3b6d5e50de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Quaternary Lake Drilling Project QLDP']/parent::*</value>
      <webElementGuid>385671af-77ad-4f65-b3e2-1c1bac585185</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'bsip_qldp.php')]</value>
      <webElementGuid>9fff6583-bd35-4b17-a070-33a786d8eb47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/a</value>
      <webElementGuid>6aa13ead-0474-4d2e-b9d3-5b45a5c79bf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'bsip_qldp.php' and (text() = 'Quaternary Lake Drilling Project QLDP' or . = 'Quaternary Lake Drilling Project QLDP')]</value>
      <webElementGuid>c77a45be-c010-46a9-b6ab-77c4807f0ac0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
