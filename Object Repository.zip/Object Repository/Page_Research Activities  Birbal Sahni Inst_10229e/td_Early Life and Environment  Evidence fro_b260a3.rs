<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Early Life and Environment  Evidence fro_b260a3</name>
   <tag></tag>
   <elementGuidId>030bca29-addd-4d19-ba0f-1d3132af5c1e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='9']/div/div/div/div/table/tbody/tr[2]/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(2) > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Early Life and Environment : Evidence from Indian Precambrian Basins&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>7977b321-cbdc-4ca1-a085-7b2ec609bfe1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Early Life and Environment : Evidence from Indian Precambrian Basins</value>
      <webElementGuid>91d7b706-e214-4e85-aed0-f552b5846213</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;9&quot;)/div[@class=&quot;panel-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;sponsered-project-container&quot;]/table[@class=&quot;table mb-0&quot;]/tbody[1]/tr[2]/td[2]</value>
      <webElementGuid>02f6b9da-38ce-482b-9488-edbd142af4ca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='9']/div/div/div/div/table/tbody/tr[2]/td[2]</value>
      <webElementGuid>f5893d04-925c-47c7-92b8-fdc113b9fba8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Project Title'])[1]/following::td[1]</value>
      <webElementGuid>82fe0273-6505-4e45-84fa-ec22c3e6dc46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Project 1'])[1]/following::td[2]</value>
      <webElementGuid>100cb631-64d3-4f95-8054-ffae62c7c57f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Coordinator'])[1]/preceding::td[1]</value>
      <webElementGuid>1ca18cb3-0af1-4021-b6f4-9b4940557fc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Veeru Kant Singh'])[1]/preceding::td[2]</value>
      <webElementGuid>6403ef36-4492-4804-a967-015c96606fc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Early Life and Environment : Evidence from Indian Precambrian Basins']/parent::*</value>
      <webElementGuid>aa2e6ce5-e7ec-4187-b39a-cfbb523dea04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[2]</value>
      <webElementGuid>2f7b6776-fb92-4fe7-a1c6-48552461310b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Early Life and Environment : Evidence from Indian Precambrian Basins' or . = 'Early Life and Environment : Evidence from Indian Precambrian Basins')]</value>
      <webElementGuid>676e45c5-3f71-41fd-909d-4201d855a1c5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
