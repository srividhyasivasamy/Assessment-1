<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>font_Birbal Sahni Institute of Palaeosciences</name>
   <tag></tag>
   <elementGuidId>9aa69572-0550-4d52-ab17-3da45872a926</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='headertbl']/tbody/tr/td/table/tbody/tr/td/font</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>font.headerFont</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Birbal Sahni Institute of Palaeosciences&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>font</value>
      <webElementGuid>ebdd2048-596b-4431-92a5-cefb8e5cac40</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>headerFont</value>
      <webElementGuid>49133d7b-f690-49d3-99cc-c4fc8eb32bf9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

Birbal Sahni Institute of Palaeosciences

				</value>
      <webElementGuid>764ff87d-45f9-4580-97be-53f3630724b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;headertbl&quot;)/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[1]/td[1]/font[@class=&quot;headerFont&quot;]</value>
      <webElementGuid>50184fbc-a1fa-4526-b1ce-a348009e154b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='headertbl']/tbody/tr/td/table/tbody/tr/td/font</value>
      <webElementGuid>fcf6382c-83f5-48ca-be98-fa5ed2f112a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Powered by LIBSYS'])[1]/preceding::font[1]</value>
      <webElementGuid>7b553056-6bfa-41cc-978d-236a4ec5386b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/preceding::font[2]</value>
      <webElementGuid>009b88a0-d486-420c-bf2f-1e496f9aeb14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Birbal Sahni Institute of Palaeosciences']/parent::*</value>
      <webElementGuid>3dec8227-159f-47bc-a813-7cdd8b2c08fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//font</value>
      <webElementGuid>cc32972f-e163-481d-84ac-cb7743b4d786</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//font[(text() = '

Birbal Sahni Institute of Palaeosciences

				' or . = '

Birbal Sahni Institute of Palaeosciences

				')]</value>
      <webElementGuid>b35daa89-cb66-422f-ba2f-df83c00aeac7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
