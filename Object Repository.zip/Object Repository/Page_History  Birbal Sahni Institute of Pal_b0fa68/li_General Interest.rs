<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_General Interest</name>
   <tag></tag>
   <elementGuidId>cf90dc6c-1b88-4e25-8f4a-64816d56f65d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.list-divider.list-border.list.check > li:nth-of-type(4)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;General Interest&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>1ce64b07-2b77-4079-b4e6-620da94effd4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>General Interest </value>
      <webElementGuid>a549831c-d758-4751-96e2-ba60d76495fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-2 col-lg-2 col-md-2&quot;]/div[@class=&quot;sidebar sidebar-right mt-sm-30&quot;]/div[@class=&quot;widget&quot;]/ul[@class=&quot;list-divider list-border list check&quot;]/li[4]</value>
      <webElementGuid>487a9222-2831-48ab-a529-73200d41e98d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[4]</value>
      <webElementGuid>5aded2ca-86a8-4292-ab74-35312c517257</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Education Career'])[2]/following::li[1]</value>
      <webElementGuid>ebbe74c9-24e5-4806-bf4b-b8fef447cd04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Parental Background'])[2]/following::li[2]</value>
      <webElementGuid>857ea7bd-297e-4efb-900c-c4a612244f85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incident of Youth'])[2]/preceding::li[1]</value>
      <webElementGuid>7b42b496-b45c-447f-a36a-16a31f7cc234</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[4]</value>
      <webElementGuid>906fbd5e-f535-4512-b5a2-dd677c000c1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'General Interest ' or . = 'General Interest ')]</value>
      <webElementGuid>a3d3c280-f778-4abb-8b21-cd22c80df7c3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
