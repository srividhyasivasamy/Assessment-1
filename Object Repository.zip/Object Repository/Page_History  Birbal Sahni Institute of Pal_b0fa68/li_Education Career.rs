<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Education Career</name>
   <tag></tag>
   <elementGuidId>d8ad896a-26a8-4d40-8f67-54f7b0333e60</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.list-divider.list-border.list.check > li:nth-of-type(3)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;Education Career&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>e65cac57-bf9c-4395-ad5f-5938238765bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Education Career </value>
      <webElementGuid>cc15ffef-86c6-4f38-8219-0331c74cadbf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-2 col-lg-2 col-md-2&quot;]/div[@class=&quot;sidebar sidebar-right mt-sm-30&quot;]/div[@class=&quot;widget&quot;]/ul[@class=&quot;list-divider list-border list check&quot;]/li[3]</value>
      <webElementGuid>835a30dc-dc84-455f-a8d4-f3f0e1a8346a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[3]</value>
      <webElementGuid>feed04f0-9635-4f0d-8a0a-d47cb0955f9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Parental Background'])[2]/following::li[1]</value>
      <webElementGuid>16b56c65-c05a-42e1-a5dc-b18f2f41b1d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='History'])[3]/following::li[2]</value>
      <webElementGuid>560f8d6d-2ff6-44a8-8600-09d8d89fd54d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Interest'])[2]/preceding::li[1]</value>
      <webElementGuid>920fc980-4f12-4925-ac58-facda7fb5116</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[3]</value>
      <webElementGuid>c96ea78e-acab-4116-af98-80039fc92604</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Education Career ' or . = 'Education Career ')]</value>
      <webElementGuid>ed3fb45d-5a69-4899-a7a7-2609a1e03f5f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
