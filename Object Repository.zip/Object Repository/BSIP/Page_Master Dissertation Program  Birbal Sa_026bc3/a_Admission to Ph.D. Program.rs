<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Admission to Ph.D. Program</name>
   <tag></tag>
   <elementGuidId>d2c8009f-7132-42f6-9cd7-f3fdb75926f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.list-divider.list-border.list.check > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Admission to Ph.D. Program&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2b6aa520-5ac7-4831-a86d-87ec287563c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>bsip_admission_to_phd.php</value>
      <webElementGuid>cf390b56-ea5d-4e00-bab2-6dbe724d6d04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Admission to Ph.D. Program</value>
      <webElementGuid>47ff50ea-5f7b-4c3a-b5d7-5c32a8a0728d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-20&quot;]/div[@class=&quot;col-xl-2 col-lg-2 col-md-2&quot;]/div[@class=&quot;sidebar sidebar-right mt-sm-30&quot;]/div[@class=&quot;widget&quot;]/ul[@class=&quot;list-divider list-border list check&quot;]/li[3]/a[1]</value>
      <webElementGuid>d202b383-683c-49f8-b29d-360dbf1fe251</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[3]/a</value>
      <webElementGuid>aeb5e3b0-5e06-4e0a-9b38-55d062a72000</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Admission to Ph.D. Program')])[2]</value>
      <webElementGuid>6c4be5b7-6b94-4d13-994c-694a200d6236</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Advertisements'])[2]/following::a[1]</value>
      <webElementGuid>cb0934a0-2cb9-4afd-9036-b53b28c12b6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bsip Recruitment Portal'])[2]/following::a[2]</value>
      <webElementGuid>a3517496-d23a-447b-b9ef-40d02f7887f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BIRBAL SAHNI BIANNUAL MASTERS DISSERTATION PROGRAMS AT BSIP'])[1]/preceding::a[3]</value>
      <webElementGuid>2ef471b9-a4c6-48ee-8674-b3bf9a3f9e46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'bsip_admission_to_phd.php')])[2]</value>
      <webElementGuid>fffc27f9-fb9e-4f76-957b-0f0a645ba1c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[3]/a</value>
      <webElementGuid>6344697f-ef53-49c8-b775-491894a5a746</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'bsip_admission_to_phd.php' and (text() = 'Admission to Ph.D. Program' or . = 'Admission to Ph.D. Program')]</value>
      <webElementGuid>a5cdf745-95ca-48e4-8859-92dc96981974</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
