<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_APPLICATION PROCEDURE</name>
   <tag></tag>
   <elementGuidId>d2479291-20ef-4daf-81e7-fa445309caaf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div[3]/div/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;APPLICATION PROCEDURE&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>e8a47a27-b453-4c79-a1d7-4da721f73bf3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-uppercase title text-dark-blue</value>
      <webElementGuid>0bd5c6e6-fb5c-4505-aa5f-d3a4c4f08f3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>APPLICATION PROCEDURE </value>
      <webElementGuid>cbd76c05-17ef-4232-afad-ec4d67d595fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row  mb-0&quot;]/div[@class=&quot;col-lg-12&quot;]/h1[@class=&quot;text-uppercase title text-dark-blue&quot;]</value>
      <webElementGuid>c22ea199-db6e-4036-a18d-b43984f2733e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div[3]/div/h1</value>
      <webElementGuid>32183b98-e883-4cb8-a7fe-69d406dc6841</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Category II:'])[1]/following::h1[1]</value>
      <webElementGuid>9ba01056-60c9-49ef-9a51-411c643ec64e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Category I:'])[1]/following::h1[1]</value>
      <webElementGuid>9a1741fb-33c2-427d-a690-52baf8924430</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='https://www.bsip.res.in'])[1]/preceding::h1[2]</value>
      <webElementGuid>0734bbf1-1234-4467-ba6a-708ec5f5f39b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='APPLICATION PROCEDURE']/parent::*</value>
      <webElementGuid>4037aff6-27e2-4165-b926-f6f00db9f6ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/h1</value>
      <webElementGuid>3b538019-2111-44c1-bd6b-28be22ceb8b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'APPLICATION PROCEDURE ' or . = 'APPLICATION PROCEDURE ')]</value>
      <webElementGuid>aae51f33-814d-4b4f-8a01-4548c36dde26</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
