<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Birbal Sahni Institute of Palaeoscience_d3fc65</name>
   <tag></tag>
   <elementGuidId>9084a2bd-923c-4314-a3d4-805ec6ab2541</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/footer/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-sm-6.col-md-3.responsive-header-top</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#wrapper div >> internal:has-text=&quot;Birbal Sahni Institute of Palaeosciences, 53 University Road , Lucknow - 226007,&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bc9cc6fd-dffa-41d8-9298-00690d7aa4c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-6 col-md-3 responsive-header-top</value>
      <webElementGuid>5a6cfea0-917b-43aa-9dda-ca34c78d15d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            
                            Birbal Sahni Institute of Palaeosciences,
                                53 University Road , Lucknow
                                - 226007,
                                Uttar Pradesh, India
                            
                                  +91-522-2742903, 2742902  
                                  director@bsip.res.in, 
                                              registrar@bsip.res.in  
                                  www.bsip.res.in 
                            
                            
                                
                                
                                
                                
                                
                                

                                
                            
                        
                    </value>
      <webElementGuid>669c402a-fb54-458c-adfd-69fedc5b7cca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/footer[@class=&quot;footer&quot;]/div[@class=&quot;container-fluid pt-20 pb-10&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-6 col-md-3 responsive-header-top&quot;]</value>
      <webElementGuid>81f0b72f-bf9d-4439-a55a-c2a5314820de</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/footer/div/div/div</value>
      <webElementGuid>3149af87-dbc8-49dc-a257-030bdd38958f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ratan_kar@bsip.res.in'])[1]/following::div[3]</value>
      <webElementGuid>b72fa82c-ec15-491e-a13a-ae23fc5573a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr. Ratan Kar, Scientist - F'])[1]/following::div[3]</value>
      <webElementGuid>006ef555-9c30-4616-8cf1-fbe9d4ebfdd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Important Links'])[1]/preceding::div[2]</value>
      <webElementGuid>9e43523a-1bef-451f-93a8-948ebe48a983</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/preceding::div[2]</value>
      <webElementGuid>0acbeb28-9b1d-4171-b9f8-ba0cafebd7f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer/div/div/div</value>
      <webElementGuid>676beaba-2c69-4ebf-bf36-efa073879c5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        
                            
                            Birbal Sahni Institute of Palaeosciences,
                                53 University Road , Lucknow
                                - 226007,
                                Uttar Pradesh, India
                            
                                  +91-522-2742903, 2742902  
                                  director@bsip.res.in, 
                                              registrar@bsip.res.in  
                                  www.bsip.res.in 
                            
                            
                                
                                
                                
                                
                                
                                

                                
                            
                        
                    ' or . = '
                        
                            
                            Birbal Sahni Institute of Palaeosciences,
                                53 University Road , Lucknow
                                - 226007,
                                Uttar Pradesh, India
                            
                                  +91-522-2742903, 2742902  
                                  director@bsip.res.in, 
                                              registrar@bsip.res.in  
                                  www.bsip.res.in 
                            
                            
                                
                                
                                
                                
                                
                                

                                
                            
                        
                    ')]</value>
      <webElementGuid>24dcf917-15b0-4dce-8981-4018a53ab011</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
