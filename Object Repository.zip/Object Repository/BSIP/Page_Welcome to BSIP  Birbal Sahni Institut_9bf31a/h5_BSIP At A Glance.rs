<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_BSIP At A Glance</name>
   <tag></tag>
   <elementGuidId>56709924-0cef-44b8-adbc-2799fa3b5a9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='about ']/div/div/div/div/div/div/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h5.text-uppercase.text-white.mb-0.mt-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;BSIP At A Glance&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>1dd4d314-b3c4-4480-b31f-f8003b659615</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-uppercase text-white mb-0 mt-0</value>
      <webElementGuid>777a3d0f-6271-48ad-86f4-9d87897c3a31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                             BSIP At A Glance
                                        </value>
      <webElementGuid>7541f70a-667a-4fc8-83ef-d6903f74272a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;about &quot;)/div[@class=&quot;container-fluid pt-20 pb-20&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-6 col-md-4&quot;]/div[@class=&quot;team-members border-bottom-theme-colored2px text-center maxwidth400 mb-30&quot;]/div[@class=&quot;event-title&quot;]/h5[@class=&quot;text-uppercase text-white mb-0 mt-0&quot;]</value>
      <webElementGuid>0f5b866e-c38f-4afa-b260-5406f2282b14</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='about ']/div/div/div/div/div/div/h5</value>
      <webElementGuid>c07965be-2ba8-4de9-bfc3-4bcc788c54fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::h5[1]</value>
      <webElementGuid>141beb90-1004-4a40-84ca-fa67451f4f30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[1]/following::h5[1]</value>
      <webElementGuid>d78e6c03-d55d-4bb9-9972-9f59ba8f3d77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='BSIP At A Glance']/parent::*</value>
      <webElementGuid>d48a179b-ebf3-4216-8de7-2c8def043395</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5</value>
      <webElementGuid>b6ab20ea-1fee-47ed-bf09-2e92abb48260</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = '
                                             BSIP At A Glance
                                        ' or . = '
                                             BSIP At A Glance
                                        ')]</value>
      <webElementGuid>675a2cff-f635-4eff-894e-ed3a601a6c18</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
