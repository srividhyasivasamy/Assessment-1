<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_Home                                Pro_fdfa62</name>
   <tag></tag>
   <elementGuidId>17f5aef2-1c68-4733-a5c9-2bc668d099f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#menuzord</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#menuzord</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
      <webElementGuid>6106bcb7-101c-41fb-831c-0b4993a117d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>menuzord</value>
      <webElementGuid>ad070c39-0448-43ac-bd33-cd033e443754</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>menuzord default menuzord-responsive</value>
      <webElementGuid>6c8703b9-39b0-4a41-a490-875113094bcd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                                Home
                                Profile
                                    
                                        History
                                        Prof. Birbal Sahni
                                            
                                                Parental
                                                        Background
                                                
                                                Education
                                                        Career
                                                
                                                General
                                                        Interest
                                                
                                                Incident
                                                        of
                                                        Youth
                                                
                                                Contributions
                                                    
                                                        Living
                                                        
                                                        Fossil
                                                        
                                                        Geology
                                                        
                                                    
                                                
                                                Honours 
                                            
                                        
                                        

                                        Mrs. Savitri
                                                Sahni
                                    
                                
                                Structure
                                    
                                        Governing Body
                                        Research Advisory
                                                Council
                                        
                                        Finance and
                                                Builidng
                                                Commitee
                                        
                                        Director
                                        Organizational Setup
                                        
                                        Past Heads of the
                                                Institute
                                        Past
                                                President/Chairman
                                        
                                    
                                
                                
                                Staff
                                    
                                        Director
                                        Scientific
                                        Technical
                                        Administrative
                                        Superannuated

                                    
                                
                                Research
                                    
                                        
                                        Research Activities
                                        Collaborations
                                        Sponsored Projects
                                        Fellowship
                                        Medals &amp; Awards
                                        Lectures
                                        Consultancy
                                    
                                
                                Publications
                                    
                                        Journal of Palaeosciences
                                        
                                        Annual Reports
                                        Catalogues
                                        Publications On Sale
                                        
                                        Research Papers

                                        Monthly Report
                                        Newsletter
                                    
                                
                                Units
                                    
                                        Museum
                                        Knowledge Resource Centre
                                        Computer Section
                                        Centre for Promotion of Geoheritage
                                                and
                                                Geotourism (CPGG)
                                        Amber Analysis and
                                                Palaeoentomology
                                                Laboratory
                                    
                                
                                Tenders
                                Career

                                    
                                        Bsip Recruitment Portal
                                        
                                        

                                        Advertisements
                                        Admission to Ph.D. Program
                                        
                                        
                                        Birbal Sahni Biannual Masters
                                                Dissertation Programs at BSIP
                                        Birbal Sahni Training
                                                Programs for Research Scholars, Postgraduate and Undergraduate
                                                Students


                                    
                                
                                Facilities
                                    
                                        Sophisticated Analytical Instruments
                                                Facilities
                                        

                                        DNA LAB
                                        FESEM
                                        C 14
                                        Section Cutting
                                        Maceration
                                    
                                
                                Events
                                    
                                        XXII INQUA 2027aDNASouthAsia
                                
                                LEM-ISS-2023
                                Picture Gallery
                                
                                Past Events
                                
                            
                            
                            Rajbhasha Patal

                            
                        </value>
      <webElementGuid>f382a952-5cc9-427b-864c-b26f5765aca3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord&quot;)</value>
      <webElementGuid>f51dade6-1e77-4562-92c9-21c46f8530c0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//nav[@id='menuzord']</value>
      <webElementGuid>3f116072-fb13-49d4-b3a7-9bd34a514fad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header']/div/div/div/div[2]/nav</value>
      <webElementGuid>b1972659-acb5-4ef8-9954-7302e5e7c31f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='हिंदी संस्करण'])[1]/following::nav[1]</value>
      <webElementGuid>45a8422d-c8ff-423d-afe6-914fa0485fca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Screen Reader Access'])[1]/following::nav[1]</value>
      <webElementGuid>538e1dd1-8ea6-43ed-80af-737ab220c94f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav</value>
      <webElementGuid>b8946153-740b-4900-83d9-b208bcb46b82</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//nav[@id = 'menuzord' and (text() = '
                            
                                Home
                                Profile
                                    
                                        History
                                        Prof. Birbal Sahni
                                            
                                                Parental
                                                        Background
                                                
                                                Education
                                                        Career
                                                
                                                General
                                                        Interest
                                                
                                                Incident
                                                        of
                                                        Youth
                                                
                                                Contributions
                                                    
                                                        Living
                                                        
                                                        Fossil
                                                        
                                                        Geology
                                                        
                                                    
                                                
                                                Honours 
                                            
                                        
                                        

                                        Mrs. Savitri
                                                Sahni
                                    
                                
                                Structure
                                    
                                        Governing Body
                                        Research Advisory
                                                Council
                                        
                                        Finance and
                                                Builidng
                                                Commitee
                                        
                                        Director
                                        Organizational Setup
                                        
                                        Past Heads of the
                                                Institute
                                        Past
                                                President/Chairman
                                        
                                    
                                
                                
                                Staff
                                    
                                        Director
                                        Scientific
                                        Technical
                                        Administrative
                                        Superannuated

                                    
                                
                                Research
                                    
                                        
                                        Research Activities
                                        Collaborations
                                        Sponsored Projects
                                        Fellowship
                                        Medals &amp; Awards
                                        Lectures
                                        Consultancy
                                    
                                
                                Publications
                                    
                                        Journal of Palaeosciences
                                        
                                        Annual Reports
                                        Catalogues
                                        Publications On Sale
                                        
                                        Research Papers

                                        Monthly Report
                                        Newsletter
                                    
                                
                                Units
                                    
                                        Museum
                                        Knowledge Resource Centre
                                        Computer Section
                                        Centre for Promotion of Geoheritage
                                                and
                                                Geotourism (CPGG)
                                        Amber Analysis and
                                                Palaeoentomology
                                                Laboratory
                                    
                                
                                Tenders
                                Career

                                    
                                        Bsip Recruitment Portal
                                        
                                        

                                        Advertisements
                                        Admission to Ph.D. Program
                                        
                                        
                                        Birbal Sahni Biannual Masters
                                                Dissertation Programs at BSIP
                                        Birbal Sahni Training
                                                Programs for Research Scholars, Postgraduate and Undergraduate
                                                Students


                                    
                                
                                Facilities
                                    
                                        Sophisticated Analytical Instruments
                                                Facilities
                                        

                                        DNA LAB
                                        FESEM
                                        C 14
                                        Section Cutting
                                        Maceration
                                    
                                
                                Events
                                    
                                        XXII INQUA 2027aDNASouthAsia
                                
                                LEM-ISS-2023
                                Picture Gallery
                                
                                Past Events
                                
                            
                            
                            Rajbhasha Patal

                            
                        ' or . = '
                            
                                Home
                                Profile
                                    
                                        History
                                        Prof. Birbal Sahni
                                            
                                                Parental
                                                        Background
                                                
                                                Education
                                                        Career
                                                
                                                General
                                                        Interest
                                                
                                                Incident
                                                        of
                                                        Youth
                                                
                                                Contributions
                                                    
                                                        Living
                                                        
                                                        Fossil
                                                        
                                                        Geology
                                                        
                                                    
                                                
                                                Honours 
                                            
                                        
                                        

                                        Mrs. Savitri
                                                Sahni
                                    
                                
                                Structure
                                    
                                        Governing Body
                                        Research Advisory
                                                Council
                                        
                                        Finance and
                                                Builidng
                                                Commitee
                                        
                                        Director
                                        Organizational Setup
                                        
                                        Past Heads of the
                                                Institute
                                        Past
                                                President/Chairman
                                        
                                    
                                
                                
                                Staff
                                    
                                        Director
                                        Scientific
                                        Technical
                                        Administrative
                                        Superannuated

                                    
                                
                                Research
                                    
                                        
                                        Research Activities
                                        Collaborations
                                        Sponsored Projects
                                        Fellowship
                                        Medals &amp; Awards
                                        Lectures
                                        Consultancy
                                    
                                
                                Publications
                                    
                                        Journal of Palaeosciences
                                        
                                        Annual Reports
                                        Catalogues
                                        Publications On Sale
                                        
                                        Research Papers

                                        Monthly Report
                                        Newsletter
                                    
                                
                                Units
                                    
                                        Museum
                                        Knowledge Resource Centre
                                        Computer Section
                                        Centre for Promotion of Geoheritage
                                                and
                                                Geotourism (CPGG)
                                        Amber Analysis and
                                                Palaeoentomology
                                                Laboratory
                                    
                                
                                Tenders
                                Career

                                    
                                        Bsip Recruitment Portal
                                        
                                        

                                        Advertisements
                                        Admission to Ph.D. Program
                                        
                                        
                                        Birbal Sahni Biannual Masters
                                                Dissertation Programs at BSIP
                                        Birbal Sahni Training
                                                Programs for Research Scholars, Postgraduate and Undergraduate
                                                Students


                                    
                                
                                Facilities
                                    
                                        Sophisticated Analytical Instruments
                                                Facilities
                                        

                                        DNA LAB
                                        FESEM
                                        C 14
                                        Section Cutting
                                        Maceration
                                    
                                
                                Events
                                    
                                        XXII INQUA 2027aDNASouthAsia
                                
                                LEM-ISS-2023
                                Picture Gallery
                                
                                Past Events
                                
                            
                            
                            Rajbhasha Patal

                            
                        ')]</value>
      <webElementGuid>c3aa55d8-8676-4f2e-b122-df95b12c06dd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
