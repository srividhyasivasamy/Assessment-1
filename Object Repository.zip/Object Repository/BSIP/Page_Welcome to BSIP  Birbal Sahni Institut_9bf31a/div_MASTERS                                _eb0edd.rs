<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_MASTERS                                _eb0edd</name>
   <tag></tag>
   <elementGuidId>90b8fbb6-d00f-419f-afa6-038db12485d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@onclick=&quot;location.href = 'bsip_master_dissertation_program.php'&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(2) > .event-box > .event-body > .row > div:nth-child(2) > .hover-eff</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9684d912-06d9-4eaa-86d1-f4de58464f0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>hover-eff</value>
      <webElementGuid>0a11a5dc-580c-4126-9e6a-5c6f1564032c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>location.href = 'bsip_master_dissertation_program.php'</value>
      <webElementGuid>b6efec2f-b899-4111-94b2-57c1ab675098</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    
                                                        
                                                        MASTER'S
                                                            DISSERTATION PROGRAMS AT BSIP
                                                    
                                                </value>
      <webElementGuid>a85e8099-34e6-4c89-8b9c-452e9880fdfe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[@id=&quot;about&quot;]/div[@class=&quot;container-fluid pt-20 pb-20&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-4 col-xl-4 col-md-4 col-sm-6 col-xs-12 border&quot;]/div[@class=&quot;event-box bg-white&quot;]/div[@class=&quot;event-body&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;hover-eff&quot;]</value>
      <webElementGuid>6e36aeae-a3ae-486f-a2a3-9ac7a7805e26</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@onclick=&quot;location.href = 'bsip_master_dissertation_program.php'&quot;]</value>
      <webElementGuid>d7dffecd-fbe3-489a-904c-52e6452d5ff7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='about']/div/div/div/div[2]/div/div[2]/div/div[2]/div</value>
      <webElementGuid>2e324311-103b-4c31-9e52-a48c4d1ea051</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Advertisement'])[1]/preceding::div[5]</value>
      <webElementGuid>ff7ffdf7-65ec-4267-a2d4-13e35f1ab347</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div[2]/div</value>
      <webElementGuid>b583f45b-dbd1-4abf-8567-a6766f02cf8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
                                                    
                                                        
                                                        MASTER&quot; , &quot;'&quot; , &quot;S
                                                            DISSERTATION PROGRAMS AT BSIP
                                                    
                                                &quot;) or . = concat(&quot;
                                                    
                                                        
                                                        MASTER&quot; , &quot;'&quot; , &quot;S
                                                            DISSERTATION PROGRAMS AT BSIP
                                                    
                                                &quot;))]</value>
      <webElementGuid>61e4eefb-79e9-4ecc-adcc-66923b531d1a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
