<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p__1</name>
   <tag></tag>
   <elementGuidId>0e2995da-0db1-43b0-8b47-d9ef181b15e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div[2]/div[2]/div[8]/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(8) > .news-image > .caption > p >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>f654db00-5415-436c-95a8-c13b708380d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                          तिमाही  हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          </value>
      <webElementGuid>a286b20d-4813-4397-9cf1-b7099c751edc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-100&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;col-lg-3 col-md-3 col-sm-6 col-xs-12&quot;]/div[@class=&quot;news-image&quot;]/div[@class=&quot;caption&quot;]/p[1]</value>
      <webElementGuid>4d43c536-9732-458f-861d-5bbb9020ecd3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div[2]/div[2]/div[8]/div/div/p</value>
      <webElementGuid>b0c54c48-a2c0-4b59-abe7-9085be8601a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/p</value>
      <webElementGuid>616d7d61-4176-44ca-b65f-a3be3c402482</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                                          तिमाही  हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          ' or . = '
                                          तिमाही  हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          ')]</value>
      <webElementGuid>52b4ceb6-8b40-4152-9071-90f7ae57206a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
