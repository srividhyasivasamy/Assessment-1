<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_</name>
   <tag></tag>
   <elementGuidId>18c7901a-d82e-4c3b-a173-4b6f218f6c69</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div[6]/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(6) > .news-image > .caption > p >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>ed67ffb5-cbd1-416a-833b-9946d47244e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                          तिमाही हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          </value>
      <webElementGuid>204d53b8-bec9-4ffe-aa06-bbed1a1818ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-100&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;col-lg-3 col-md-3 col-sm-6 col-xs-12&quot;]/div[@class=&quot;news-image&quot;]/div[@class=&quot;caption&quot;]/p[1]</value>
      <webElementGuid>131c95a2-4fa3-40a9-80f3-512913996386</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div[6]/div/div/p</value>
      <webElementGuid>a9c24fce-4bc4-45f7-973b-ea8a333fc48a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/div/p</value>
      <webElementGuid>e70268cf-9440-46b2-8cfb-8046c5beddfe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                                          तिमाही हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          ' or . = '
                                          तिमाही हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          ')]</value>
      <webElementGuid>d78f9de3-b867-4b92-9a40-5cf35ce47ba2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
