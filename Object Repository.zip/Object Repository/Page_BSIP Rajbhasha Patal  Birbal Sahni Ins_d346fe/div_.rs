<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_</name>
   <tag></tag>
   <elementGuidId>be5ecd6e-1ea8-4621-9344-c72706282c91</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div[4]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(4) > .news-image > .caption >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d7da44f4-0079-4281-b2bc-e488c88b5f12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>caption</value>
      <webElementGuid>68fea601-be7c-4499-b37f-a29a8a459bda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                          
                                          तिमाही हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          
                                      </value>
      <webElementGuid>23d161e5-93da-4d91-bed9-0de388744e3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-100&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;col-lg-3 col-md-3 col-sm-6 col-xs-12&quot;]/div[@class=&quot;news-image&quot;]/div[@class=&quot;caption&quot;]</value>
      <webElementGuid>16012929-44d6-4985-ab83-ce475348215b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div[4]/div/div</value>
      <webElementGuid>37909c75-5d9c-4094-8625-57e7dce20dba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[4]/div/div</value>
      <webElementGuid>7e551ee2-1e92-4667-b6ca-7d35ed39d31c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                          
                                          तिमाही हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          
                                      ' or . = '
                                          
                                          तिमाही हिंदी कार्यशाला के अंतर्गत व्याख्यान                                          
                                      ')]</value>
      <webElementGuid>3c7ee82d-d9d4-49c6-acdb-c1fe90daad7e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
