<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Career_fa fa-angle-down</name>
   <tag></tag>
   <elementGuidId>3978924d-5572-43a7-9407-273255d1709e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord']/ul/li[9]/a/span/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(9) > a > span.indicator > i.fa.fa-angle-down</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Career &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>def48f2b-e6bd-4eac-8df7-c276b89087f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-angle-down</value>
      <webElementGuid>8cb499a4-dfbe-4b05-8c56-c73c44a04a36</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord&quot;)/ul[@class=&quot;menuzord-menu menuzord-indented scrollable&quot;]/li[9]/a[1]/span[@class=&quot;indicator&quot;]/i[@class=&quot;fa fa-angle-down&quot;]</value>
      <webElementGuid>8a67b486-88a5-4662-af82-3e02bb2803ce</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='menuzord']/ul/li[9]/a/span/i</value>
      <webElementGuid>ae831e7e-2803-440b-afb4-c8dd24d8311d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[9]/a/span/i</value>
      <webElementGuid>c647ab10-07d2-4dd8-8292-9525c600d0f5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
