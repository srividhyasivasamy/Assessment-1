<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Facilities_fa fa-angle-down</name>
   <tag></tag>
   <elementGuidId>c7b02e74-e16e-48e6-ac97-fe95a61f0561</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord']/ul/li[10]/a/span/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(10) > a > span.indicator > i.fa.fa-angle-down</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Facilities &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>4338d2b7-41a6-42c5-ae52-85e2a70d890a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-angle-down</value>
      <webElementGuid>980fa920-666d-4bb4-993d-b9af600655f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord&quot;)/ul[@class=&quot;menuzord-menu menuzord-indented scrollable&quot;]/li[10]/a[1]/span[@class=&quot;indicator&quot;]/i[@class=&quot;fa fa-angle-down&quot;]</value>
      <webElementGuid>b42f0d66-5a2a-44e8-8c8a-00f2029aa0e4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='menuzord']/ul/li[10]/a/span/i</value>
      <webElementGuid>cb6344ff-84fe-401b-8a75-c6a2f96b4bd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/a/span/i</value>
      <webElementGuid>0bbcc4c4-af2e-4935-8528-0663e641abb8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
