<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Education Career</name>
   <tag></tag>
   <elementGuidId>ff351e4f-ebf7-45d8-ae86-f93227978141</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.list-divider.list-border.list.check > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Education Career&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7e801060-89c0-40e5-863c-ceeb299e3117</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>bsip_Prof_birbal_Sahni_education_career.php</value>
      <webElementGuid>e55deb4c-9683-4446-a66e-71e8441078d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Education Career</value>
      <webElementGuid>37736831-9a75-4936-b9bf-92a471135a83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-2 col-lg-2 col-md-3&quot;]/div[@class=&quot;sidebar sidebar-right mt-sm-30&quot;]/div[@class=&quot;widget&quot;]/ul[@class=&quot;list-divider list-border list check&quot;]/li[3]/a[1]</value>
      <webElementGuid>500d7bfb-b021-4e11-8f87-a4e3c4bba49d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li[3]/a</value>
      <webElementGuid>c7548d5d-2fb4-4f58-ad1b-79514bcb7d4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Education Career')]</value>
      <webElementGuid>35cf100c-e006-4bc1-ada7-e3a653358109</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Parental Background'])[2]/following::a[1]</value>
      <webElementGuid>edb41473-df92-4e55-ab0a-f18e7445043a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='History'])[2]/following::a[2]</value>
      <webElementGuid>7349f23e-8bb8-4314-9535-015244277902</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Interest'])[2]/preceding::a[1]</value>
      <webElementGuid>d6f8d768-5bb4-4666-971e-be8a131ba9b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incident of Youth'])[2]/preceding::a[2]</value>
      <webElementGuid>4bd3730d-df86-42a0-be03-f0b5d8600ffd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'bsip_Prof_birbal_Sahni_education_career.php')])[2]</value>
      <webElementGuid>8ac1266a-83d2-4f9a-af7d-3a7b773bc1dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[3]/a</value>
      <webElementGuid>9310e749-2d5e-4485-a2dd-69c576c89f7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'bsip_Prof_birbal_Sahni_education_career.php' and (text() = 'Education Career' or . = 'Education Career')]</value>
      <webElementGuid>973ae490-0db8-4a98-9a8f-d89a3408259d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
