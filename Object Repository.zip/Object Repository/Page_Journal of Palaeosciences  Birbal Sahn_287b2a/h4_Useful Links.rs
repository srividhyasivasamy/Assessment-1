<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Useful Links</name>
   <tag></tag>
   <elementGuidId>1e4a16df-3560-4758-b7af-3009764aeeea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/footer/div/div/div[3]/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Useful Links&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>7d12922d-55ea-4121-8f0b-4ddbee61c992</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>widget-title line-bottom-theme-colored-2</value>
      <webElementGuid>ccabc72e-c197-44bb-936f-7fbc821f77bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Useful Links</value>
      <webElementGuid>8f7f22e4-6459-4123-9807-8972a188e8f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/footer[@class=&quot;footer&quot;]/div[@class=&quot;container-fluid pt-20 pb-10&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-6 col-md-3 responsive-header-top&quot;]/div[@class=&quot;widget dark&quot;]/h4[@class=&quot;widget-title line-bottom-theme-colored-2&quot;]</value>
      <webElementGuid>a67497a5-d165-43c2-804b-67c2aeb452e5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/footer/div/div/div[3]/div/h4</value>
      <webElementGuid>d6a4230e-e84c-43ee-8e75-b284a6a463f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IC Committee'])[1]/following::h4[1]</value>
      <webElementGuid>cc012c32-6eb4-4b70-bb4d-ca084b51d5a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BSIP Outreach Program'])[1]/following::h4[1]</value>
      <webElementGuid>a5dcfb87-37ca-487c-acf3-b25576d869fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Intranet'])[1]/preceding::h4[1]</value>
      <webElementGuid>a1d0755a-fe36-41ca-943f-7984f3193faf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Useful Links']/parent::*</value>
      <webElementGuid>fbccf589-d7c6-4c14-9ac4-c8dc37c0eb80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/h4</value>
      <webElementGuid>087fa25e-234a-4047-92ab-cafbc24835c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Useful Links' or . = 'Useful Links')]</value>
      <webElementGuid>551a07a5-55b4-4ead-843b-1ccd7a4ac862</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
