<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_Home                                Pro_fdfa62</name>
   <tag></tag>
   <elementGuidId>3be75bac-da09-4632-a591-67126bde08f8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#menuzord</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#menuzord</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
      <webElementGuid>b38f7be1-432a-4bca-80c4-5936f3b1785d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>menuzord</value>
      <webElementGuid>ec4b13f2-29af-472b-9d74-fd24ad40f741</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>menuzord default menuzord-responsive</value>
      <webElementGuid>c8716f7d-d5bf-4e7c-b548-af60ac7998cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                                Home
                                Profile
                                    
                                        History
                                        Prof. Birbal Sahni
                                            
                                                Parental
                                                        Background
                                                
                                                Education
                                                        Career
                                                
                                                General
                                                        Interest
                                                
                                                Incident
                                                        of
                                                        Youth
                                                
                                                Contributions
                                                    
                                                        Living
                                                        
                                                        Fossil
                                                        
                                                        Geology
                                                        
                                                    
                                                
                                                Honours 
                                            
                                        
                                        

                                        Mrs. Savitri
                                                Sahni
                                    
                                
                                Structure
                                    
                                        Governing Body
                                        Research Advisory
                                                Council
                                        
                                        Finance and
                                                Builidng
                                                Commitee
                                        
                                        Director
                                        Organizational Setup
                                        
                                        Past Heads of the
                                                Institute
                                        Past
                                                President/Chairman
                                        
                                    
                                
                                
                                Staff
                                    
                                        Director
                                        Scientific
                                        Technical
                                        Administrative
                                        Superannuated

                                    
                                
                                Research
                                    
                                        
                                        Research Activities
                                        Collaborations
                                        Sponsored Projects
                                        Fellowship
                                        Medals &amp; Awards
                                        Lectures
                                        Consultancy
                                    
                                
                                Publications
                                    
                                        Journal of Palaeosciences
                                        
                                        Annual Reports
                                        Catalogues
                                        Publications On Sale
                                        
                                        Research Papers

                                        Monthly Report
                                        Newsletter
                                    
                                
                                Units
                                    
                                        Museum
                                        Knowledge Resource Centre
                                        Computer Section
                                        Centre for Promotion of Geoheritage
                                                and
                                                Geotourism (CPGG)
                                        Amber Analysis and
                                                Palaeoentomology
                                                Laboratory
                                    
                                
                                Tenders
                                Career

                                    
                                        Bsip Recruitment Portal
                                        
                                        

                                        Advertisements
                                        Admission to Ph.D. Program
                                        
                                        
                                        Birbal Sahni Biannual Masters
                                                Dissertation Programs at BSIP
                                        Birbal Sahni Training
                                                Programs for Research Scholars, Postgraduate and Undergraduate
                                                Students


                                    
                                
                                Facilities
                                    
                                        Sophisticated Analytical Instruments
                                                Facilities
                                        

                                        DNA LAB
                                        FESEM
                                        C 14
                                        Section Cutting
                                        Maceration
                                    
                                
                                Events
                                    
                                        XXII INQUA 2027aDNASouthAsia
                                
                                LEM-ISS-2023
                                Picture Gallery
                                
                                Past Events
                                
                            
                            
                            Rajbhasha Patal

                            
                        </value>
      <webElementGuid>3fa60c2a-06ca-4828-94cb-2f66f499a790</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord&quot;)</value>
      <webElementGuid>5f48b172-5c62-4dd0-9d46-4c882774cd3f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//nav[@id='menuzord']</value>
      <webElementGuid>cecc885b-a6f4-4f92-bd20-9a8a97f18574</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header']/div/div/div/div[2]/nav</value>
      <webElementGuid>f72e7276-16aa-40be-a02f-419afd637be2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='हिंदी संस्करण'])[1]/following::nav[1]</value>
      <webElementGuid>81c52991-2839-4423-9a8f-9175255cce3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Screen Reader Access'])[1]/following::nav[1]</value>
      <webElementGuid>96da08d4-8c75-4dbf-85fd-28e8671b0099</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav</value>
      <webElementGuid>c3417df6-e8f9-4438-928d-0b18dfde464e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//nav[@id = 'menuzord' and (text() = '
                            
                                Home
                                Profile
                                    
                                        History
                                        Prof. Birbal Sahni
                                            
                                                Parental
                                                        Background
                                                
                                                Education
                                                        Career
                                                
                                                General
                                                        Interest
                                                
                                                Incident
                                                        of
                                                        Youth
                                                
                                                Contributions
                                                    
                                                        Living
                                                        
                                                        Fossil
                                                        
                                                        Geology
                                                        
                                                    
                                                
                                                Honours 
                                            
                                        
                                        

                                        Mrs. Savitri
                                                Sahni
                                    
                                
                                Structure
                                    
                                        Governing Body
                                        Research Advisory
                                                Council
                                        
                                        Finance and
                                                Builidng
                                                Commitee
                                        
                                        Director
                                        Organizational Setup
                                        
                                        Past Heads of the
                                                Institute
                                        Past
                                                President/Chairman
                                        
                                    
                                
                                
                                Staff
                                    
                                        Director
                                        Scientific
                                        Technical
                                        Administrative
                                        Superannuated

                                    
                                
                                Research
                                    
                                        
                                        Research Activities
                                        Collaborations
                                        Sponsored Projects
                                        Fellowship
                                        Medals &amp; Awards
                                        Lectures
                                        Consultancy
                                    
                                
                                Publications
                                    
                                        Journal of Palaeosciences
                                        
                                        Annual Reports
                                        Catalogues
                                        Publications On Sale
                                        
                                        Research Papers

                                        Monthly Report
                                        Newsletter
                                    
                                
                                Units
                                    
                                        Museum
                                        Knowledge Resource Centre
                                        Computer Section
                                        Centre for Promotion of Geoheritage
                                                and
                                                Geotourism (CPGG)
                                        Amber Analysis and
                                                Palaeoentomology
                                                Laboratory
                                    
                                
                                Tenders
                                Career

                                    
                                        Bsip Recruitment Portal
                                        
                                        

                                        Advertisements
                                        Admission to Ph.D. Program
                                        
                                        
                                        Birbal Sahni Biannual Masters
                                                Dissertation Programs at BSIP
                                        Birbal Sahni Training
                                                Programs for Research Scholars, Postgraduate and Undergraduate
                                                Students


                                    
                                
                                Facilities
                                    
                                        Sophisticated Analytical Instruments
                                                Facilities
                                        

                                        DNA LAB
                                        FESEM
                                        C 14
                                        Section Cutting
                                        Maceration
                                    
                                
                                Events
                                    
                                        XXII INQUA 2027aDNASouthAsia
                                
                                LEM-ISS-2023
                                Picture Gallery
                                
                                Past Events
                                
                            
                            
                            Rajbhasha Patal

                            
                        ' or . = '
                            
                                Home
                                Profile
                                    
                                        History
                                        Prof. Birbal Sahni
                                            
                                                Parental
                                                        Background
                                                
                                                Education
                                                        Career
                                                
                                                General
                                                        Interest
                                                
                                                Incident
                                                        of
                                                        Youth
                                                
                                                Contributions
                                                    
                                                        Living
                                                        
                                                        Fossil
                                                        
                                                        Geology
                                                        
                                                    
                                                
                                                Honours 
                                            
                                        
                                        

                                        Mrs. Savitri
                                                Sahni
                                    
                                
                                Structure
                                    
                                        Governing Body
                                        Research Advisory
                                                Council
                                        
                                        Finance and
                                                Builidng
                                                Commitee
                                        
                                        Director
                                        Organizational Setup
                                        
                                        Past Heads of the
                                                Institute
                                        Past
                                                President/Chairman
                                        
                                    
                                
                                
                                Staff
                                    
                                        Director
                                        Scientific
                                        Technical
                                        Administrative
                                        Superannuated

                                    
                                
                                Research
                                    
                                        
                                        Research Activities
                                        Collaborations
                                        Sponsored Projects
                                        Fellowship
                                        Medals &amp; Awards
                                        Lectures
                                        Consultancy
                                    
                                
                                Publications
                                    
                                        Journal of Palaeosciences
                                        
                                        Annual Reports
                                        Catalogues
                                        Publications On Sale
                                        
                                        Research Papers

                                        Monthly Report
                                        Newsletter
                                    
                                
                                Units
                                    
                                        Museum
                                        Knowledge Resource Centre
                                        Computer Section
                                        Centre for Promotion of Geoheritage
                                                and
                                                Geotourism (CPGG)
                                        Amber Analysis and
                                                Palaeoentomology
                                                Laboratory
                                    
                                
                                Tenders
                                Career

                                    
                                        Bsip Recruitment Portal
                                        
                                        

                                        Advertisements
                                        Admission to Ph.D. Program
                                        
                                        
                                        Birbal Sahni Biannual Masters
                                                Dissertation Programs at BSIP
                                        Birbal Sahni Training
                                                Programs for Research Scholars, Postgraduate and Undergraduate
                                                Students


                                    
                                
                                Facilities
                                    
                                        Sophisticated Analytical Instruments
                                                Facilities
                                        

                                        DNA LAB
                                        FESEM
                                        C 14
                                        Section Cutting
                                        Maceration
                                    
                                
                                Events
                                    
                                        XXII INQUA 2027aDNASouthAsia
                                
                                LEM-ISS-2023
                                Picture Gallery
                                
                                Past Events
                                
                            
                            
                            Rajbhasha Patal

                            
                        ')]</value>
      <webElementGuid>620f4617-8c62-4c3d-b60d-1c8a7fec616b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
