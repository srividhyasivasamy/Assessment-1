<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_Download PDF</name>
   <tag></tag>
   <elementGuidId>6e9890ec-e98c-4599-95b4-73871072148c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div[2]/div[2]/div/table/thead/tr/th[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Download PDF&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>3a8fad29-d12b-4928-af1d-0be31632bdce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Download PDF</value>
      <webElementGuid>f4673abc-adc2-4d51-9c18-ae6bd1748e47</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-100&quot;]/div[@class=&quot;col-md-12&quot;]/table[@class=&quot;table past-head table-bordered&quot;]/thead[1]/tr[1]/th[3]</value>
      <webElementGuid>1860a57f-716a-42df-a54d-c9cc9de8f584</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div[2]/div[2]/div/table/thead/tr/th[3]</value>
      <webElementGuid>572ed9d8-1566-4497-8db5-ca13207a615d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notice/ Updates'])[4]/following::th[1]</value>
      <webElementGuid>8fd166c3-9673-4317-96db-6d08e950845b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sl No.'])[2]/following::th[2]</value>
      <webElementGuid>1ae79171-31dd-4ef3-aa17-338cbbf7b259</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[8]/preceding::th[1]</value>
      <webElementGuid>760a6b76-d85d-4c89-818d-8ab2bd883296</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[9]/preceding::th[1]</value>
      <webElementGuid>579b5b75-9c4d-4968-ac81-d150e72a0725</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/table/thead/tr/th[3]</value>
      <webElementGuid>106e0906-da4a-44f9-9160-39b27d0c2c0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Download PDF' or . = 'Download PDF')]</value>
      <webElementGuid>9f2e6b37-90d8-40a4-a95c-b1b81cd3c40a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
