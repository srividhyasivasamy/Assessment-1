<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Regarding Refund of Application Fees in _4daf62</name>
   <tag></tag>
   <elementGuidId>d0091da2-278d-4bf6-929f-e97fb45916b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div[2]/div/table/tbody/tr[2]/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(2) > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Regarding Refund of Application Fees in Connection to the Advertisement for the post of Technical Assistant-D advertised vide Advertisement No : BSIP/Rec./08/2022 dated 02.08.2022&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>b76f8ba2-e9f9-49fd-bcd4-41f476821895</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Regarding Refund of Application Fees in Connection to the Advertisement for the post of Technical Assistant-D advertised vide Advertisement No : BSIP/Rec./08/2022 dated 02.08.2022 </value>
      <webElementGuid>6de963ef-f2a5-42cc-8c9b-9a451ef35229</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-100&quot;]/div[@class=&quot;col-md-12&quot;]/table[@class=&quot;table past-head table-bordered&quot;]/tbody[1]/tr[2]/td[2]</value>
      <webElementGuid>bc97dbb9-74ab-48d9-80eb-2eed7ddf1a3e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div[2]/div/table/tbody/tr[2]/td[2]</value>
      <webElementGuid>cd2b3fc9-7740-451d-b881-4fa12b9dc3a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/following::td[2]</value>
      <webElementGuid>32039f1d-705b-452a-b736-68119c572e4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download PDF'])[1]/following::td[5]</value>
      <webElementGuid>e0f125d7-2f7f-40ca-89ce-e388289b21cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[2]/preceding::td[1]</value>
      <webElementGuid>70be8d2b-2e3a-4065-a283-27063c67eddc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The importance of Indian Amber from the Eocene of Cambay and Kutch Basins for MOES'])[1]/preceding::td[3]</value>
      <webElementGuid>11be7f32-9401-400f-a711-eb33b9ea8b5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Regarding Refund of Application Fees in Connection to the Advertisement for the post of Technical Assistant-D advertised vide Advertisement No : BSIP/Rec./08/2022 dated 02.08.2022']/parent::*</value>
      <webElementGuid>b55cf1ac-1dd1-4b5b-a8ff-7959e298f9be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[2]</value>
      <webElementGuid>994fe6f9-6df8-4213-9e98-f93759220dc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Regarding Refund of Application Fees in Connection to the Advertisement for the post of Technical Assistant-D advertised vide Advertisement No : BSIP/Rec./08/2022 dated 02.08.2022 ' or . = 'Regarding Refund of Application Fees in Connection to the Advertisement for the post of Technical Assistant-D advertised vide Advertisement No : BSIP/Rec./08/2022 dated 02.08.2022 ')]</value>
      <webElementGuid>e6678e6b-2e7f-4c3b-8343-bc07ae4e2acf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
