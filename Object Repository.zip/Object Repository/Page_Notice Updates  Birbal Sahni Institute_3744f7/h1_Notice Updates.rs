<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Notice Updates</name>
   <tag></tag>
   <elementGuidId>85b3718d-22cd-4749-9f24-542a929935a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.text-uppercase.title.text-dark-blue</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Notice/ Updates&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>c3de4664-9fc6-4950-bb44-ebf54478d947</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-uppercase title text-dark-blue</value>
      <webElementGuid>a8da831e-e1f4-48d8-8665-4d4a6263f27e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Notice/ Updates</value>
      <webElementGuid>ebf53d34-4cb0-46b3-8e33-e4fffcf078ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row  mb-0&quot;]/div[@class=&quot;col-lg-12&quot;]/h1[@class=&quot;text-uppercase title text-dark-blue&quot;]</value>
      <webElementGuid>c4c15cb7-d2ef-4c1c-957b-6116c45d8b32</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/h1</value>
      <webElementGuid>b5239d8c-153e-4c13-9d17-511b831abb91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notice/ Updates'])[1]/following::h1[1]</value>
      <webElementGuid>f22c735c-3716-42d8-818c-4adf1931461a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[2]/following::h1[1]</value>
      <webElementGuid>f6c968a9-447b-46b3-8d4a-f1b3dd67aaaf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sl No.'])[1]/preceding::h1[1]</value>
      <webElementGuid>ca677c62-bb19-49f9-85a7-3906a30d9160</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notice/ Updates'])[3]/preceding::h1[1]</value>
      <webElementGuid>e8f56bc9-f8ed-4243-88b2-36157de870f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>fd4d675f-0379-4362-a0f6-fc0c5d61daa4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Notice/ Updates' or . = 'Notice/ Updates')]</value>
      <webElementGuid>6edff61f-cb22-4710-8ceb-38d631b80eee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
