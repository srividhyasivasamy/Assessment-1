<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Walk - in - Interview for the post of Ra_a48a81</name>
   <tag></tag>
   <elementGuidId>13044fc3-c210-4c9d-92c0-4e3cb82b365d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div[2]/div[2]/div/table/tbody/tr/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Walk - in - Interview for the post of Radiation Safety Officer (RSO) Level - 2 Certification (Industrial Radiography) on 22.5.2024 at 11.00 AM&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>1b4657cb-d3f4-4d8f-a04d-9047704bb97b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Walk - in - Interview for the post of Radiation Safety Officer (RSO) Level - 2 Certification (Industrial Radiography) on 22.5.2024 at 11.00 AM </value>
      <webElementGuid>c0e1901d-5204-41e1-90c7-2e3c04613856</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-100&quot;]/div[@class=&quot;col-md-12&quot;]/table[@class=&quot;table past-head table-bordered&quot;]/tbody[1]/tr[1]/td[2]</value>
      <webElementGuid>2221a261-cfe9-414f-95b3-ad074f0121d5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div[2]/div[2]/div/table/tbody/tr/td[2]</value>
      <webElementGuid>d3e4c589-43b0-47a1-99e5-d3f4d7d99dcc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download PDF'])[2]/following::td[2]</value>
      <webElementGuid>52bdc1dc-2bef-440b-a814-f4625642bcbd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notice/ Updates'])[4]/following::td[2]</value>
      <webElementGuid>4951dd1a-36af-435f-afa1-f93e48f7ce53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[8]/preceding::td[1]</value>
      <webElementGuid>1aab6f69-0e17-41f4-a691-229b383886a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[9]/preceding::td[4]</value>
      <webElementGuid>8db83a23-4858-4a5e-ae3c-3c9a63890267</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Walk - in - Interview for the post of Radiation Safety Officer (RSO) Level - 2 Certification (Industrial Radiography) on 22.5.2024 at 11.00 AM']/parent::*</value>
      <webElementGuid>0453a2d3-e570-492d-96b1-bd6ff3988ab7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/table/tbody/tr/td[2]</value>
      <webElementGuid>59e8b01f-41de-40c2-89c3-0c173c724ade</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Walk - in - Interview for the post of Radiation Safety Officer (RSO) Level - 2 Certification (Industrial Radiography) on 22.5.2024 at 11.00 AM ' or . = 'Walk - in - Interview for the post of Radiation Safety Officer (RSO) Level - 2 Certification (Industrial Radiography) on 22.5.2024 at 11.00 AM ')]</value>
      <webElementGuid>0ec96759-0765-4e9e-9bd3-dcbb6245d27f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
