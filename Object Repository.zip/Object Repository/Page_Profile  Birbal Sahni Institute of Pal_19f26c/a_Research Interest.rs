<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Research Interest</name>
   <tag></tag>
   <elementGuidId>d6ed5833-e333-4ae5-92a8-72d0686ea854</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-tabs.nav-stacked > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Research Interest&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6ea6fbbb-fc89-49a3-b37f-c8816a910944</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-toggle</name>
      <type>Main</type>
      <value>tab</value>
      <webElementGuid>0235194e-e8c7-4611-a9fc-f72faa1c7d9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#home</value>
      <webElementGuid>81578487-b9a7-4b41-8f14-50057ae94be2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Research Interest  </value>
      <webElementGuid>94cd255f-0c8c-446f-b1d4-b3d9ca3f613b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-4&quot;]/div[@class=&quot;profile&quot;]/ul[@class=&quot;nav nav-tabs nav-stacked&quot;]/li[1]/a[1]</value>
      <webElementGuid>cd20b075-94b6-4e16-9f1b-a5f2043aaf80</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/ul/li/a</value>
      <webElementGuid>e4f8709e-865e-4099-91ff-8692d572a215</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Research Interest')]</value>
      <webElementGuid>fc0f9f07-158c-420b-afdd-e2e9c5785fc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Director'])[3]/following::a[1]</value>
      <webElementGuid>4577d54a-e405-4817-b36d-2b1bde19fe53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[2]/following::a[1]</value>
      <webElementGuid>b8f6a5c7-f1bd-48f9-9c73-e21135e074d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Awards and Honors'])[1]/preceding::a[1]</value>
      <webElementGuid>f2900f73-0a52-4b21-9dd1-84aac820d081</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publications'])[2]/preceding::a[2]</value>
      <webElementGuid>b5b0393e-061b-4d54-9505-c94027db7c7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Research Interest']/parent::*</value>
      <webElementGuid>12b51722-12ec-42e9-98ab-314eda4f7891</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#home')]</value>
      <webElementGuid>0b4250b3-2c6e-4680-a0fe-58b912514e7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li/a</value>
      <webElementGuid>ce1cdf5e-52d6-468e-8872-57ee5d5b2e59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#home' and (text() = ' Research Interest  ' or . = ' Research Interest  ')]</value>
      <webElementGuid>f5c03c41-1632-4ac8-9cf0-2eb872441dd4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
