<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Prof. Mahesh G. Thakkar</name>
   <tag></tag>
   <elementGuidId>e78d3cb1-a0b0-457c-9e93-db4e1bfbc755</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div/div/div/div/table/tbody/tr/td</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>table.table.table-borderless > tbody > tr > td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Prof. Mahesh G. Thakkar&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>953b5378-c095-4dfc-b3a7-5c9418126d34</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Prof. Mahesh G. Thakkar</value>
      <webElementGuid>24ebc78c-b8c8-413c-b67e-45a34554d42a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-9&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[1]/div[@class=&quot;col-sm-8&quot;]/table[@class=&quot;table table-borderless&quot;]/tbody[1]/tr[1]/td[1]</value>
      <webElementGuid>8b5ab15c-565c-4bef-9c8b-c218acccb149</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div[2]/div/div/div/div/table/tbody/tr/td</value>
      <webElementGuid>230c171a-b521-4aa2-81e0-9d7025e53d0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAME :'])[1]/following::td[1]</value>
      <webElementGuid>730cb9da-60f8-48ae-9676-5f4394775cfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download CV'])[1]/following::td[1]</value>
      <webElementGuid>222daf90-99b4-41c6-a79d-4e29a7d04aa0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DESIGNATION :'])[1]/preceding::td[1]</value>
      <webElementGuid>b765e08a-dbb5-4ece-ac6b-ef3ec532651c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Director'])[4]/preceding::td[1]</value>
      <webElementGuid>0b654ef8-d509-4973-b9ab-aaefc2c354c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Prof. Mahesh G. Thakkar']/parent::*</value>
      <webElementGuid>bb4ead61-9e65-4fa9-a541-d75cc61b64d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/table/tbody/tr/td</value>
      <webElementGuid>59aa7169-aabc-4488-a2f1-6ec6ef3fd6b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Prof. Mahesh G. Thakkar' or . = 'Prof. Mahesh G. Thakkar')]</value>
      <webElementGuid>29c8a2bf-500e-4590-8640-d2cc024847ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
