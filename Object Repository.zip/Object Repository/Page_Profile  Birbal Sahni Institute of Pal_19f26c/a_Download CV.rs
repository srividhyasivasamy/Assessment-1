<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Download CV</name>
   <tag></tag>
   <elementGuidId>c6ea09c0-7dd5-424c-a1c6-517203382843</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/ul/li[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-tabs.nav-stacked > li:nth-of-type(5) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Download CV&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>64bc61fb-eef2-4249-9c1e-b6562195e26b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-toggle</name>
      <type>Main</type>
      <value>tab</value>
      <webElementGuid>ce880799-dea7-4ead-9f31-aa3cf85c8921</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#menu3</value>
      <webElementGuid>8ab1b705-c05b-46a7-affe-4393e5fb003f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Download CV </value>
      <webElementGuid>555b90df-4062-4026-ad9c-5645d4f56eef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-4&quot;]/div[@class=&quot;profile&quot;]/ul[@class=&quot;nav nav-tabs nav-stacked&quot;]/li[5]/a[1]</value>
      <webElementGuid>db270e06-bc80-43ef-b737-82c07dca302a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/ul/li[5]/a</value>
      <webElementGuid>d3bfd206-addd-414d-963e-f8bdb34b0cd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Download CV')]</value>
      <webElementGuid>d381d19b-8878-4f01-84dd-d480e62b2774</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Membership of Professional Societies'])[1]/following::a[1]</value>
      <webElementGuid>828b3289-0101-442d-8e4f-b21f02f047da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publications'])[2]/following::a[2]</value>
      <webElementGuid>54428315-1d21-43b6-bd68-33d0197ab26c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAME :'])[1]/preceding::a[1]</value>
      <webElementGuid>19701dd7-45bd-4007-85b2-8ce256a52429</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Prof. Mahesh G. Thakkar'])[1]/preceding::a[1]</value>
      <webElementGuid>b68572fc-419f-4b5b-8339-45ac33b952dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Download CV']/parent::*</value>
      <webElementGuid>769ea62e-bcd8-4a3d-89ce-b92d0883f66a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#menu3')]</value>
      <webElementGuid>78b9359e-2533-4825-a66e-bcb16cbfb4e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[5]/a</value>
      <webElementGuid>1502bd34-edee-450b-8b70-a4c14fb2ab29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#menu3' and (text() = 'Download CV ' or . = 'Download CV ')]</value>
      <webElementGuid>e4ae3444-8e1b-4e8f-9cb1-7380c1e3f522</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
