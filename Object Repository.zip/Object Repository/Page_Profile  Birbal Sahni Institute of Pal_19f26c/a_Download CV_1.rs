<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Download CV_1</name>
   <tag></tag>
   <elementGuidId>cbec57da-b77a-47cd-814e-464dac7ea589</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value> </value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-primary.btn-xs</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#menu3 >> internal:role=link[name=&quot;Download CV&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a1e47dd8-251b-482e-8c5f-a95d5f4dbf2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>138bbaae-f2c4-4820-a265-0aad3b67391b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.bsip.res.in/admin/assets/pdf-file/mgthakkar-23.pdf</value>
      <webElementGuid>b4ef2020-48ef-4e01-a7f4-99522ab6cb25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-xs</value>
      <webElementGuid>c9da9e9a-9c78-449f-a343-d5e7d684746d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    Download CV </value>
      <webElementGuid>d1e04d04-eb88-45cb-94b0-11942ac25447</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menu3&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-9&quot;]/a[@class=&quot;btn btn-primary btn-xs&quot;]</value>
      <webElementGuid>5eced2d9-1df3-4863-b038-9e48c3a97e03</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='menu3']/div[2]/div/a</value>
      <webElementGuid>671bc810-85b6-46f8-9829-85e37b775319</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Download CV')])[2]</value>
      <webElementGuid>a5bd21a5-8a89-4750-a303-1cbc51ed671f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='You can download CV here:'])[1]/following::a[1]</value>
      <webElementGuid>f71e514a-ef83-441a-8064-91ef4a0ce0ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CV'])[1]/following::a[1]</value>
      <webElementGuid>a2df5e39-8059-42e9-8128-87f865cb3a7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Details'])[1]/preceding::a[1]</value>
      <webElementGuid>bb19f45d-b940-4e39-9a72-be5319f459e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.bsip.res.in/admin/assets/pdf-file/mgthakkar-23.pdf')]</value>
      <webElementGuid>0ba33064-f421-4e1d-bd02-071ca3b27fb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a</value>
      <webElementGuid>d7ab5f00-6dcd-42ff-bf29-ea410d2e0e6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.bsip.res.in/admin/assets/pdf-file/mgthakkar-23.pdf' and (text() = '
                                                    Download CV ' or . = '
                                                    Download CV ')]</value>
      <webElementGuid>e058282e-0474-43c2-98db-d828e6cbc77f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
