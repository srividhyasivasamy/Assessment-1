<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Membership of Professional Societies</name>
   <tag></tag>
   <elementGuidId>6dd496dd-0da4-4f20-a3ba-748fb2e7a7d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/ul/li[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-tabs.nav-stacked > li:nth-of-type(4) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Membership of Professional Societies&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>112405b1-ec2d-470b-983e-0e0f9489b95b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-toggle</name>
      <type>Main</type>
      <value>tab</value>
      <webElementGuid>0e9e6f10-9157-46d5-b796-c4aaf96ea3ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#menu2</value>
      <webElementGuid>7235df08-f233-416a-a2c4-2eb0bb3601e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Membership of Professional Societies </value>
      <webElementGuid>ac45d0a9-d480-4192-9803-e1b3c44f0e68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-4&quot;]/div[@class=&quot;profile&quot;]/ul[@class=&quot;nav nav-tabs nav-stacked&quot;]/li[4]/a[1]</value>
      <webElementGuid>d24cd329-c24f-4d8c-9af5-34dfd4c19f26</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/ul/li[4]/a</value>
      <webElementGuid>96c0bde8-24c4-4be5-9fb2-cf20d7cefb89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Membership of Professional Societies')]</value>
      <webElementGuid>aa7ca090-7ead-4645-b35d-501cbe53c324</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publications'])[2]/following::a[1]</value>
      <webElementGuid>ad9272e7-5bd4-4c7d-ac13-f5d5bc345ee8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Awards and Honors'])[1]/following::a[2]</value>
      <webElementGuid>f4dab97c-f969-471e-9dd9-97cb68896d39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download CV'])[1]/preceding::a[1]</value>
      <webElementGuid>271cce4e-5ab3-4f85-8206-4d00210e22a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAME :'])[1]/preceding::a[2]</value>
      <webElementGuid>cf4d15bb-1994-460f-adbe-09b529658447</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Membership of Professional Societies']/parent::*</value>
      <webElementGuid>903f7af8-10fc-4c07-b92d-39bd62c2fb30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#menu2')]</value>
      <webElementGuid>bd4b2c4f-f25e-4f91-b7bd-b576fdd24edc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[4]/a</value>
      <webElementGuid>63f974ac-a7c0-42b6-a302-8ceb8b3aae69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#menu2' and (text() = ' Membership of Professional Societies ' or . = ' Membership of Professional Societies ')]</value>
      <webElementGuid>fb8181b0-d9b1-40bc-9431-dafdf9e9a155</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
