<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Journal of Palaeosciences</name>
   <tag></tag>
   <elementGuidId>437152cf-2792-4a82-ae04-74e83a1b4e14</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.list-divider.list-border.list.check > li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=/^Journal of Palaeosciences$/</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>1262ead9-3a37-4a31-85ce-9c40bf3fdcc2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Journal of Palaeosciences</value>
      <webElementGuid>fddeb4eb-961c-4040-933f-2c0da18a1a40</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]/div[@class=&quot;section-content&quot;]/div[@class=&quot;row mb-100&quot;]/div[@class=&quot;col-xl-2 col-lg-2 col-md-2&quot;]/div[@class=&quot;sidebar sidebar-right mt-sm-30&quot;]/div[@class=&quot;widget&quot;]/ul[@class=&quot;list-divider list-border list check&quot;]/li[1]</value>
      <webElementGuid>10359c63-889f-4cb5-b9db-8bdb82f22fd9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div/div/div/div/div/div/ul/li</value>
      <webElementGuid>453cb845-42b6-47b5-8881-ead6c05ddb00</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publications'])[2]/following::li[1]</value>
      <webElementGuid>47c99d23-88ee-4dd2-803f-f9ee6d670bf0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Monthly Report'])[2]/following::li[1]</value>
      <webElementGuid>00279d8c-53f4-4acf-bc44-d50c12cec2b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Reports'])[2]/preceding::li[1]</value>
      <webElementGuid>570dadb4-2a8f-4cd6-8736-ba8cb64e1dfd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li</value>
      <webElementGuid>5a1c5975-7b7b-48a1-bc95-5bcedcc4c589</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Journal of Palaeosciences' or . = 'Journal of Palaeosciences')]</value>
      <webElementGuid>2e6113e8-52cc-4968-8bf4-1c03e184ddd9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
