<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Previous                               _3f09e1</name>
   <tag></tag>
   <elementGuidId>4eab774d-c6e7-4b5f-bec5-435bd77235e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='wrapper']/div[2]/section[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.container-fluid.pt-30.pb-40</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Previous Next Publications: Tripathi, S., Thakur, B., Sharma, A., Phartiyal, B.,&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b8502705-7f88-460f-bbad-bc3458ae7e66</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container-fluid pt-30 pb-40</value>
      <webElementGuid>3323dfd2-6bc1-4aa3-a3fb-e8cdd08b65e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	    

            
                
                
                    
                    
                    
                    
                
                
                
                
                
                
                    
                        
                        
                             
                        
                    
                
                
                    
                        
                        
                            
                        
                    
                
                    
                        
                        
                             
                        
                    
                    
                        
                        
                             
                        
                    
                    
                        
                        
                             
                        
                    
                    
                
                
                

                
                
                    
                    Previous
                
                
                    
                    Next
                
            
        

            
                
                    
                
                
                    Publications:
                        
                    
                        Tripathi, S., Thakur, B., Sharma, A., Phartiyal, B.,
                        Basumatary, S. K., Ghosh, R., ... &amp; Bose, T. (2023).
                        Modern biotic and abiotic analogues from the surface
                        soil of Ganga-Ghaghara-Gandak interfluves of the Central
                        Ganga Plain (CGP), India: Implications for the
                        palaeoecological reconstructions. Catena, 224, 106975.
                    
                    
                
            
            
                
                    
                              The distinct topographical and geographical features of
                        the Indian subcontinent provide varying climatic zones
                        together with diverse vegetation types governed by the
                        southwest and the northeast monsoon, depending upon the
                        season. These monsoonal winds exhibit a rich variety of
                        natural variations on different timescales ranging
                        across sub-seasonal/intra-seasonal, interannual
                        (year-to-year), multi-decadal and centennial timescales,
                        which are evident from instrumental records and
                        paleoclimate reconstructions, commonly known as monsoon
                        variability. The frequency of extreme Indian summer
                        monsoon (ISM) events has increased in recent decades,
                        and there is significant spatial heterogeneity in the
                        occurrence of extreme events. Moreover, the duration and
                        intensity of ISM have altered during the past few years
                        and is unpredictable, causing tremendous agricultural
                        and economic loss. Future climate modelling requires
                        rigorous and accurate palaeoclimatic data, which is yet
                        to be generated, especially from the Ganga Plain (GP)
                        and Core Monsoon Zone (CMZ), mainly comprising Madhya
                        Pradesh, Maharashtra and Chhattisgarh states.
                              To fill these information gaps in regard to ISM, the
                        Quaternary Lake Drilling Project (QLDP) project aims to
                        reconstruct the monsoon-driven climatic history of the
                        terrestrial environment in the aforementioned regions to
                        study major impacts on society.
                              Lakes are considerably the best recorders of climate
                        variability on terrestrial ecosystems as sediments
                        accumulated from the surrounding environment and
                        microorganisms produced within provide high-resolution
                        histories of local environmental conditions, lake water
                        chemistry, temperature and lake productivity in the
                        past. A modern analogue of biotic and abiotic records
                        from the
                
                
                    surface samples procured in and around the lake offers a
                        quantifiable interpretation of past climate from the
                        sedimentary archives of the lake. Additionally,
                        generating tree ring width and isotope datasets can
                        reconstruct climatic parameters with the annual
                        resolution, pushing calibration periods further from
                        instrumental observations. Further, Species distribution
                        models (SDMs) identify species ecological niches as
                        geographic space, which, in combination with species
                        distributions in past and present as mapped in QLDP,
                        will provide future projections of vegetation dynamics
                        under the anticipated global warming and climate change
                        scenarios.
                        The QLDP project has the following objectives:

                        
                            To reconstruct the palaeo-climate and -hydroclimate
                                variability during the late Quaternary using multi-proxy
                                records and spatiotemporal mapping of abrupt and extreme
                                climate events
        
                                To access chronological lag and disparity in long-term
                                    records and ascertain the causal mechanisms of climate
                                    vs. vegetation
        
                                To study climate-culture interaction in this region and
                                    social response variables
        
                                Palaeoclimate modelling
                                
                                Creation of awareness and outreach for dissemination of
                                    knowledge to society
                        

                        The project's first stage focuses on
                        
                            
                                Northwest India - Haryana, Rajasthan, western Uttar
                                Pradesh
                                Central Ganga plains - central and western Uttar
                                Pradesh, Bihar
                                Core monsoon zone - Maharashtra, Madhya Pradesh,
                                    Chhattisgarh
                        
                    
                
            
        </value>
      <webElementGuid>9d40fded-fc84-46f0-846d-c33df9bf441f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrapper&quot;)/div[@class=&quot;main-content&quot;]/section[2]/div[@class=&quot;container-fluid pt-30 pb-40&quot;]</value>
      <webElementGuid>7744a188-aa18-4368-aeeb-85e980d103ee</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='wrapper']/div[2]/section[2]/div</value>
      <webElementGuid>f8c53956-7b2e-482d-83fb-9a7edcb83670</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quaternary Lake Drilling Project QLDP'])[1]/following::div[1]</value>
      <webElementGuid>8ef7fc17-3da3-43fd-be27-cb85fe23bafa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[2]/following::div[1]</value>
      <webElementGuid>feacbad2-f01f-4cc9-b077-f76d0f65295c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div</value>
      <webElementGuid>e077a731-a8e2-4914-976e-7f6a9a9441c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
	    

            
                
                
                    
                    
                    
                    
                
                
                
                
                
                
                    
                        
                        
                             
                        
                    
                
                
                    
                        
                        
                            
                        
                    
                
                    
                        
                        
                             
                        
                    
                    
                        
                        
                             
                        
                    
                    
                        
                        
                             
                        
                    
                    
                
                
                

                
                
                    
                    Previous
                
                
                    
                    Next
                
            
        

            
                
                    
                
                
                    Publications:
                        
                    
                        Tripathi, S., Thakur, B., Sharma, A., Phartiyal, B.,
                        Basumatary, S. K., Ghosh, R., ... &amp; Bose, T. (2023).
                        Modern biotic and abiotic analogues from the surface
                        soil of Ganga-Ghaghara-Gandak interfluves of the Central
                        Ganga Plain (CGP), India: Implications for the
                        palaeoecological reconstructions. Catena, 224, 106975.
                    
                    
                
            
            
                
                    
                              The distinct topographical and geographical features of
                        the Indian subcontinent provide varying climatic zones
                        together with diverse vegetation types governed by the
                        southwest and the northeast monsoon, depending upon the
                        season. These monsoonal winds exhibit a rich variety of
                        natural variations on different timescales ranging
                        across sub-seasonal/intra-seasonal, interannual
                        (year-to-year), multi-decadal and centennial timescales,
                        which are evident from instrumental records and
                        paleoclimate reconstructions, commonly known as monsoon
                        variability. The frequency of extreme Indian summer
                        monsoon (ISM) events has increased in recent decades,
                        and there is significant spatial heterogeneity in the
                        occurrence of extreme events. Moreover, the duration and
                        intensity of ISM have altered during the past few years
                        and is unpredictable, causing tremendous agricultural
                        and economic loss. Future climate modelling requires
                        rigorous and accurate palaeoclimatic data, which is yet
                        to be generated, especially from the Ganga Plain (GP)
                        and Core Monsoon Zone (CMZ), mainly comprising Madhya
                        Pradesh, Maharashtra and Chhattisgarh states.
                              To fill these information gaps in regard to ISM, the
                        Quaternary Lake Drilling Project (QLDP) project aims to
                        reconstruct the monsoon-driven climatic history of the
                        terrestrial environment in the aforementioned regions to
                        study major impacts on society.
                              Lakes are considerably the best recorders of climate
                        variability on terrestrial ecosystems as sediments
                        accumulated from the surrounding environment and
                        microorganisms produced within provide high-resolution
                        histories of local environmental conditions, lake water
                        chemistry, temperature and lake productivity in the
                        past. A modern analogue of biotic and abiotic records
                        from the
                
                
                    surface samples procured in and around the lake offers a
                        quantifiable interpretation of past climate from the
                        sedimentary archives of the lake. Additionally,
                        generating tree ring width and isotope datasets can
                        reconstruct climatic parameters with the annual
                        resolution, pushing calibration periods further from
                        instrumental observations. Further, Species distribution
                        models (SDMs) identify species ecological niches as
                        geographic space, which, in combination with species
                        distributions in past and present as mapped in QLDP,
                        will provide future projections of vegetation dynamics
                        under the anticipated global warming and climate change
                        scenarios.
                        The QLDP project has the following objectives:

                        
                            To reconstruct the palaeo-climate and -hydroclimate
                                variability during the late Quaternary using multi-proxy
                                records and spatiotemporal mapping of abrupt and extreme
                                climate events
        
                                To access chronological lag and disparity in long-term
                                    records and ascertain the causal mechanisms of climate
                                    vs. vegetation
        
                                To study climate-culture interaction in this region and
                                    social response variables
        
                                Palaeoclimate modelling
                                
                                Creation of awareness and outreach for dissemination of
                                    knowledge to society
                        

                        The project&quot; , &quot;'&quot; , &quot;s first stage focuses on
                        
                            
                                Northwest India - Haryana, Rajasthan, western Uttar
                                Pradesh
                                Central Ganga plains - central and western Uttar
                                Pradesh, Bihar
                                Core monsoon zone - Maharashtra, Madhya Pradesh,
                                    Chhattisgarh
                        
                    
                
            
        &quot;) or . = concat(&quot;
	    

            
                
                
                    
                    
                    
                    
                
                
                
                
                
                
                    
                        
                        
                             
                        
                    
                
                
                    
                        
                        
                            
                        
                    
                
                    
                        
                        
                             
                        
                    
                    
                        
                        
                             
                        
                    
                    
                        
                        
                             
                        
                    
                    
                
                
                

                
                
                    
                    Previous
                
                
                    
                    Next
                
            
        

            
                
                    
                
                
                    Publications:
                        
                    
                        Tripathi, S., Thakur, B., Sharma, A., Phartiyal, B.,
                        Basumatary, S. K., Ghosh, R., ... &amp; Bose, T. (2023).
                        Modern biotic and abiotic analogues from the surface
                        soil of Ganga-Ghaghara-Gandak interfluves of the Central
                        Ganga Plain (CGP), India: Implications for the
                        palaeoecological reconstructions. Catena, 224, 106975.
                    
                    
                
            
            
                
                    
                              The distinct topographical and geographical features of
                        the Indian subcontinent provide varying climatic zones
                        together with diverse vegetation types governed by the
                        southwest and the northeast monsoon, depending upon the
                        season. These monsoonal winds exhibit a rich variety of
                        natural variations on different timescales ranging
                        across sub-seasonal/intra-seasonal, interannual
                        (year-to-year), multi-decadal and centennial timescales,
                        which are evident from instrumental records and
                        paleoclimate reconstructions, commonly known as monsoon
                        variability. The frequency of extreme Indian summer
                        monsoon (ISM) events has increased in recent decades,
                        and there is significant spatial heterogeneity in the
                        occurrence of extreme events. Moreover, the duration and
                        intensity of ISM have altered during the past few years
                        and is unpredictable, causing tremendous agricultural
                        and economic loss. Future climate modelling requires
                        rigorous and accurate palaeoclimatic data, which is yet
                        to be generated, especially from the Ganga Plain (GP)
                        and Core Monsoon Zone (CMZ), mainly comprising Madhya
                        Pradesh, Maharashtra and Chhattisgarh states.
                              To fill these information gaps in regard to ISM, the
                        Quaternary Lake Drilling Project (QLDP) project aims to
                        reconstruct the monsoon-driven climatic history of the
                        terrestrial environment in the aforementioned regions to
                        study major impacts on society.
                              Lakes are considerably the best recorders of climate
                        variability on terrestrial ecosystems as sediments
                        accumulated from the surrounding environment and
                        microorganisms produced within provide high-resolution
                        histories of local environmental conditions, lake water
                        chemistry, temperature and lake productivity in the
                        past. A modern analogue of biotic and abiotic records
                        from the
                
                
                    surface samples procured in and around the lake offers a
                        quantifiable interpretation of past climate from the
                        sedimentary archives of the lake. Additionally,
                        generating tree ring width and isotope datasets can
                        reconstruct climatic parameters with the annual
                        resolution, pushing calibration periods further from
                        instrumental observations. Further, Species distribution
                        models (SDMs) identify species ecological niches as
                        geographic space, which, in combination with species
                        distributions in past and present as mapped in QLDP,
                        will provide future projections of vegetation dynamics
                        under the anticipated global warming and climate change
                        scenarios.
                        The QLDP project has the following objectives:

                        
                            To reconstruct the palaeo-climate and -hydroclimate
                                variability during the late Quaternary using multi-proxy
                                records and spatiotemporal mapping of abrupt and extreme
                                climate events
        
                                To access chronological lag and disparity in long-term
                                    records and ascertain the causal mechanisms of climate
                                    vs. vegetation
        
                                To study climate-culture interaction in this region and
                                    social response variables
        
                                Palaeoclimate modelling
                                
                                Creation of awareness and outreach for dissemination of
                                    knowledge to society
                        

                        The project&quot; , &quot;'&quot; , &quot;s first stage focuses on
                        
                            
                                Northwest India - Haryana, Rajasthan, western Uttar
                                Pradesh
                                Central Ganga plains - central and western Uttar
                                Pradesh, Bihar
                                Core monsoon zone - Maharashtra, Madhya Pradesh,
                                    Chhattisgarh
                        
                    
                
            
        &quot;))]</value>
      <webElementGuid>7e4f901c-e4b9-4631-be30-c39473763a23</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
